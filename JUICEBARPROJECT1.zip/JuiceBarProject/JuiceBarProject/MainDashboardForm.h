#pragma once
#include "AppIncludes.h"
#include "Juice.h"
#include "FreshJuice.h"
#include "MilkShake.h"
#include "Smoothie.h"
#include "OrderItem.h"
#include "Order.h"
#include "DatabaseManager.h"
#include "ManageMenuForm.h"
#include "OrderHistoryForm.h"
#include "DbSettingsForm.h"

namespace JuiceBarProject {

    public ref class MainDashboardForm : public System::Windows::Forms::Form {
    public:
        MainDashboardForm(void) {
            InitializeComponent();
            currentOrder = gcnew Order();
            activeCategory = "All Drinks";
            LoadCatalogFromDb();
        }

    protected:
        ~MainDashboardForm() {
            if (components) {
                delete components;
            }
        }

    private:
        System::ComponentModel::Container ^components;

        // Domain State
        Order^ currentOrder;
        DataTable^ catalogTable;
        String^ activeCategory;
        DataRow^ selectedJuiceRow;
        int selectedCartIndex;

        // Top Navigation Bar
        Panel^ topNavPanel;
        Label^ lblLogo;
        Label^ lblTagline;
        Label^ lblSearchIcon;
        TextBox^ txtSearch;
        Label^ lblDineIn;
        ComboBox^ cmbDineIn;
        Label^ lblCashierBadge;

        // Left Category Sidebar
        Panel^ leftCategoryPanel;
        Button^ btnCatAll;
        Button^ btnCatFresh;
        Button^ btnCatMilkshake;
        Button^ btnCatSmoothie;
        Button^ btnCatSpecial;

        // Center Product Card Grid
        Panel^ centerPanel;
        FlowLayoutPanel^ flowDrinkCards;

        // Right Order Ticket Panel
        Panel^ rightTicketPanel;
        Label^ lblTicketTitle;
        Label^ lblCustomer;
        TextBox^ txtCustomer;
        DataGridView^ gridCart;

        // Customization Controls for Selected Item
        Panel^ customizerPanel;
        Label^ lblCustHeader;
        Label^ lblSize;
        ComboBox^ cmbSize;
        Label^ lblSugar;
        ComboBox^ cmbSugar;
        Label^ lblIce;
        ComboBox^ cmbIce;
        CheckBox^ chkExtraTopping;
        Label^ lblQty;
        Button^ btnQtyMinus;
        Label^ lblQtyVal;
        Button^ btnQtyPlus;
        Button^ btnRemoveItem;

        // Ticket Summary & PAY Bar
        Panel^ ticketSummaryPanel;
        Label^ lblSubtotalTitle;
        Label^ lblSubtotalVal;
        Label^ lblDiscountTitle;
        ComboBox^ cmbDiscount;
        Label^ lblGrandTotalTitle;
        Label^ lblGrandTotalVal;
        Button^ btnPay;

        // Bottom Action Bar
        Panel^ bottomBarPanel;
        Button^ btnNavMenu;
        Button^ btnNavOrders;
        Button^ btnClearCart;
        Button^ btnRefresh;

        // Payment Modal Dialog Controls
        Form^ dlgPay;
        TextBox^ txtPayTender;
        Label^ lblPayChange;

        void InitializeComponent(void) {
            this->components = gcnew System::ComponentModel::Container();
            this->Size = System::Drawing::Size(1280, 800);
            this->MinimumSize = System::Drawing::Size(1200, 750);
            this->Text = "Juice Bar";
            this->StartPosition = FormStartPosition::CenterScreen;
            this->BackColor = Color::FromArgb(248, 250, 248); // Fresh Soft Light Tone
            this->Font = gcnew System::Drawing::Font("Segoe UI", 9.5F);

            selectedCartIndex = -1;

            // ==========================================
            // 1. TOP HEADER BAR (Full Width Spanning)
            // ==========================================
            topNavPanel = gcnew Panel();
            topNavPanel->Dock = DockStyle::Top;
            topNavPanel->Height = 65;
            topNavPanel->BackColor = Color::White;
            topNavPanel->BorderStyle = BorderStyle::FixedSingle;

            // Brand Logo & Subtitle
            lblLogo = gcnew Label();
            lblLogo->Text = "Juice Bar";
            lblLogo->ForeColor = Color::FromArgb(22, 101, 52); // Fresh Natural Botanical Green (#166534)
            lblLogo->Font = gcnew System::Drawing::Font("Segoe UI", 17.0F, FontStyle::Bold);
            lblLogo->Location = Point(18, 8);
            lblLogo->AutoSize = true;
            topNavPanel->Controls->Add(lblLogo);

            lblTagline = gcnew Label();
            lblTagline->Text = "FRESH & NATURAL BEVERAGES";
            lblTagline->ForeColor = Color::FromArgb(234, 88, 12); // Citrus Orange (#EA580C)
            lblTagline->Font = gcnew System::Drawing::Font("Segoe UI", 7.5F, FontStyle::Bold);
            lblTagline->Location = Point(20, 40);
            lblTagline->AutoSize = true;
            topNavPanel->Controls->Add(lblTagline);

            // Search Box with ample spacing
            lblSearchIcon = gcnew Label();
            lblSearchIcon->Text = "Search:";
            lblSearchIcon->Font = gcnew System::Drawing::Font("Segoe UI", 9.5F, FontStyle::Bold);
            lblSearchIcon->ForeColor = Color::FromArgb(75, 85, 99);
            lblSearchIcon->Location = Point(220, 20);
            lblSearchIcon->AutoSize = true;
            topNavPanel->Controls->Add(lblSearchIcon);

            txtSearch = gcnew TextBox();
            txtSearch->Location = Point(280, 17);
            txtSearch->Size = System::Drawing::Size(270, 26);
            txtSearch->Font = gcnew System::Drawing::Font("Segoe UI", 10.0F);
            txtSearch->TextChanged += gcnew EventHandler(this, &MainDashboardForm::txtSearch_TextChanged);
            topNavPanel->Controls->Add(txtSearch);

            // Order Type Selector
            lblDineIn = gcnew Label();
            lblDineIn->Text = "Order Type:";
            lblDineIn->Font = gcnew System::Drawing::Font("Segoe UI", 9.5F);
            lblDineIn->ForeColor = Color::FromArgb(75, 85, 99);
            lblDineIn->Location = Point(870, 20);
            lblDineIn->AutoSize = true;
            topNavPanel->Controls->Add(lblDineIn);

            cmbDineIn = gcnew ComboBox();
            cmbDineIn->Location = Point(955, 17);
            cmbDineIn->Size = System::Drawing::Size(110, 26);
            cmbDineIn->DropDownStyle = ComboBoxStyle::DropDownList;
            cmbDineIn->Items->AddRange(gcnew cli::array<Object^> { "Dine In", "Takeaway" });
            cmbDineIn->SelectedIndex = 0;
            topNavPanel->Controls->Add(cmbDineIn);

            // Cashier Badge
            lblCashierBadge = gcnew Label();
            lblCashierBadge->Text = "Counter: 01";
            lblCashierBadge->Font = gcnew System::Drawing::Font("Segoe UI", 9.5F, FontStyle::Bold);
            lblCashierBadge->ForeColor = Color::FromArgb(22, 101, 52);
            lblCashierBadge->Location = Point(1090, 20);
            lblCashierBadge->AutoSize = true;
            topNavPanel->Controls->Add(lblCashierBadge);

            // ==========================================
            // 2. BOTTOM ACTION BAR
            // ==========================================
            bottomBarPanel = gcnew Panel();
            bottomBarPanel->Dock = DockStyle::Bottom;
            bottomBarPanel->Height = 52;
            bottomBarPanel->BackColor = Color::FromArgb(22, 56, 44); // Deep Botanical Green

            btnNavMenu = gcnew Button();
            btnNavMenu->Text = "Manage Menu";
            btnNavMenu->Size = System::Drawing::Size(145, 38);
            btnNavMenu->Location = Point(15, 7);
            btnNavMenu->BackColor = Color::FromArgb(5, 150, 105); // Fresh Mint/Emerald Green (#059669)
            btnNavMenu->ForeColor = Color::White;
            btnNavMenu->Font = gcnew System::Drawing::Font("Segoe UI", 9.5F, FontStyle::Bold);
            btnNavMenu->FlatStyle = FlatStyle::Flat;
            btnNavMenu->FlatAppearance->BorderSize = 0;
            btnNavMenu->Cursor = Cursors::Hand;
            btnNavMenu->Click += gcnew EventHandler(this, &MainDashboardForm::btnNavMenu_Click);
            bottomBarPanel->Controls->Add(btnNavMenu);

            btnNavOrders = gcnew Button();
            btnNavOrders->Text = "Order History";
            btnNavOrders->Size = System::Drawing::Size(145, 38);
            btnNavOrders->Location = Point(170, 7);
            btnNavOrders->BackColor = Color::FromArgb(2, 132, 199); // Tropical Ocean Teal (#0284C7)
            btnNavOrders->ForeColor = Color::White;
            btnNavOrders->Font = gcnew System::Drawing::Font("Segoe UI", 9.5F, FontStyle::Bold);
            btnNavOrders->FlatStyle = FlatStyle::Flat;
            btnNavOrders->FlatAppearance->BorderSize = 0;
            btnNavOrders->Cursor = Cursors::Hand;
            btnNavOrders->Click += gcnew EventHandler(this, &MainDashboardForm::btnNavOrders_Click);
            bottomBarPanel->Controls->Add(btnNavOrders);

            btnRefresh = gcnew Button();
            btnRefresh->Text = "Refresh Menu";
            btnRefresh->Size = System::Drawing::Size(130, 38);
            btnRefresh->Location = Point(325, 7);
            btnRefresh->BackColor = Color::FromArgb(71, 85, 105); // Slate
            btnRefresh->ForeColor = Color::White;
            btnRefresh->Font = gcnew System::Drawing::Font("Segoe UI", 9.5F, FontStyle::Bold);
            btnRefresh->FlatStyle = FlatStyle::Flat;
            btnRefresh->FlatAppearance->BorderSize = 0;
            btnRefresh->Cursor = Cursors::Hand;
            btnRefresh->Click += gcnew EventHandler(this, &MainDashboardForm::btnRefresh_Click);
            bottomBarPanel->Controls->Add(btnRefresh);

            btnClearCart = gcnew Button();
            btnClearCart->Text = "Clear Order";
            btnClearCart->Size = System::Drawing::Size(125, 38);
            btnClearCart->Location = Point(465, 7);
            btnClearCart->BackColor = Color::FromArgb(225, 29, 72); // Fresh Rose Red
            btnClearCart->ForeColor = Color::White;
            btnClearCart->Font = gcnew System::Drawing::Font("Segoe UI", 9.5F, FontStyle::Bold);
            btnClearCart->FlatStyle = FlatStyle::Flat;
            btnClearCart->FlatAppearance->BorderSize = 0;
            btnClearCart->Cursor = Cursors::Hand;
            btnClearCart->Click += gcnew EventHandler(this, &MainDashboardForm::btnClearCart_Click);
            bottomBarPanel->Controls->Add(btnClearCart);

            // ==========================================
            // 3. LEFT CATEGORY SIDEBAR
            // ==========================================
            leftCategoryPanel = gcnew Panel();
            leftCategoryPanel->Dock = DockStyle::Left;
            leftCategoryPanel->Width = 170;
            leftCategoryPanel->BackColor = Color::FromArgb(22, 56, 44); // Deep Botanical Green

            int catY = 12;
            int catH = 54;
            int catSpacing = 4;

            btnCatAll = CreateCategoryButton("All Drinks", catY);
            catY += catH + catSpacing;

            btnCatFresh = CreateCategoryButton("Fresh Juices", catY);
            catY += catH + catSpacing;

            btnCatMilkshake = CreateCategoryButton("Milkshakes", catY);
            catY += catH + catSpacing;

            btnCatSmoothie = CreateCategoryButton("Smoothies", catY);
            catY += catH + catSpacing;

            btnCatSpecial = CreateCategoryButton("Favorites", catY);

            leftCategoryPanel->Controls->Add(btnCatAll);
            leftCategoryPanel->Controls->Add(btnCatFresh);
            leftCategoryPanel->Controls->Add(btnCatMilkshake);
            leftCategoryPanel->Controls->Add(btnCatSmoothie);
            leftCategoryPanel->Controls->Add(btnCatSpecial);

            // ==========================================
            // 4. RIGHT ORDER TICKET PANEL
            // ==========================================
            rightTicketPanel = gcnew Panel();
            rightTicketPanel->Dock = DockStyle::Right;
            rightTicketPanel->Width = 430;
            rightTicketPanel->BackColor = Color::White;
            rightTicketPanel->BorderStyle = BorderStyle::FixedSingle;

            // Ticket Header
            lblTicketTitle = gcnew Label();
            lblTicketTitle->Text = "Current Order";
            lblTicketTitle->Font = gcnew System::Drawing::Font("Segoe UI", 13.0F, FontStyle::Bold);
            lblTicketTitle->ForeColor = Color::FromArgb(22, 101, 52); // Fresh Green
            lblTicketTitle->Location = Point(15, 12);
            lblTicketTitle->AutoSize = true;
            rightTicketPanel->Controls->Add(lblTicketTitle);

            lblCustomer = gcnew Label();
            lblCustomer->Text = "Customer:";
            lblCustomer->Font = gcnew System::Drawing::Font("Segoe UI", 9.0F);
            lblCustomer->ForeColor = Color::FromArgb(107, 114, 128);
            lblCustomer->Location = Point(160, 16);
            lblCustomer->AutoSize = true;
            rightTicketPanel->Controls->Add(lblCustomer);

            txtCustomer = gcnew TextBox();
            txtCustomer->Text = "Walk-in Customer";
            txtCustomer->Font = gcnew System::Drawing::Font("Segoe UI", 9.0F);
            txtCustomer->Location = Point(225, 13);
            txtCustomer->Size = System::Drawing::Size(185, 24);
            rightTicketPanel->Controls->Add(txtCustomer);

            // Cart Items Grid (Clean columns: Item, Size, Qty, Total)
            gridCart = gcnew DataGridView();
            gridCart->Location = Point(15, 46);
            gridCart->Size = System::Drawing::Size(395, 230);
            gridCart->BackgroundColor = Color::FromArgb(250, 250, 250);
            gridCart->ReadOnly = true;
            gridCart->AllowUserToAddRows = false;
            gridCart->SelectionMode = DataGridViewSelectionMode::FullRowSelect;
            gridCart->MultiSelect = false;
            gridCart->RowHeadersVisible = false;
            gridCart->BorderStyle = BorderStyle::FixedSingle;
            gridCart->DefaultCellStyle->SelectionBackColor = Color::FromArgb(255, 160, 0); // Warm Honey Amber
            gridCart->DefaultCellStyle->SelectionForeColor = Color::FromArgb(33, 33, 33);
            gridCart->DefaultCellStyle->Font = gcnew System::Drawing::Font("Segoe UI", 9.0F);
            gridCart->RowTemplate->Height = 30;

            gridCart->Columns->Add("Item", "Drink Item");
            gridCart->Columns->Add("Size", "Size");
            gridCart->Columns->Add("Qty", "Qty");
            gridCart->Columns->Add("Total", "Total (LKR)");
            gridCart->Columns["Item"]->Width = 165;
            gridCart->Columns["Size"]->Width = 65;
            gridCart->Columns["Qty"]->Width = 45;
            gridCart->Columns["Total"]->Width = 95;
            gridCart->Columns["Size"]->DefaultCellStyle->Alignment = DataGridViewContentAlignment::MiddleCenter;
            gridCart->Columns["Qty"]->DefaultCellStyle->Alignment = DataGridViewContentAlignment::MiddleCenter;
            gridCart->Columns["Total"]->DefaultCellStyle->Alignment = DataGridViewContentAlignment::MiddleRight;

            gridCart->SelectionChanged += gcnew EventHandler(this, &MainDashboardForm::gridCart_SelectionChanged);
            rightTicketPanel->Controls->Add(gridCart);

            // Quick Customizer for Selected Cart Item
            customizerPanel = gcnew Panel();
            customizerPanel->Location = Point(15, 284);
            customizerPanel->Size = System::Drawing::Size(395, 125);
            customizerPanel->BackColor = Color::FromArgb(246, 249, 246);
            customizerPanel->BorderStyle = BorderStyle::FixedSingle;

            lblCustHeader = gcnew Label();
            lblCustHeader->Text = "Drink Customization";
            lblCustHeader->Font = gcnew System::Drawing::Font("Segoe UI", 9.0F, FontStyle::Bold);
            lblCustHeader->ForeColor = Color::FromArgb(22, 101, 52);
            lblCustHeader->Location = Point(10, 8);
            lblCustHeader->AutoSize = true;
            customizerPanel->Controls->Add(lblCustHeader);

            // Size Selector
            lblSize = gcnew Label();
            lblSize->Text = "Size:";
            lblSize->Location = Point(10, 32);
            lblSize->AutoSize = true;
            lblSize->Font = gcnew System::Drawing::Font("Segoe UI", 8.5F);
            customizerPanel->Controls->Add(lblSize);

            cmbSize = gcnew ComboBox();
            cmbSize->Location = Point(45, 29);
            cmbSize->Size = System::Drawing::Size(85, 23);
            cmbSize->DropDownStyle = ComboBoxStyle::DropDownList;
            cmbSize->Font = gcnew System::Drawing::Font("Segoe UI", 8.5F);
            cmbSize->Items->AddRange(gcnew cli::array<Object^> { "Regular", "Medium", "Large" });
            cmbSize->SelectedIndex = 0;
            cmbSize->SelectedIndexChanged += gcnew EventHandler(this, &MainDashboardForm::OnCustomizationChanged);
            customizerPanel->Controls->Add(cmbSize);

            // Sugar Selector
            lblSugar = gcnew Label();
            lblSugar->Text = "Sugar:";
            lblSugar->Location = Point(138, 32);
            lblSugar->AutoSize = true;
            lblSugar->Font = gcnew System::Drawing::Font("Segoe UI", 8.5F);
            customizerPanel->Controls->Add(lblSugar);

            cmbSugar = gcnew ComboBox();
            cmbSugar->Location = Point(180, 29);
            cmbSugar->Size = System::Drawing::Size(95, 23);
            cmbSugar->DropDownStyle = ComboBoxStyle::DropDownList;
            cmbSugar->Font = gcnew System::Drawing::Font("Segoe UI", 8.5F);
            cmbSugar->Items->AddRange(gcnew cli::array<Object^> { "100% Normal", "50% Half", "No Sugar" });
            cmbSugar->SelectedIndex = 0;
            cmbSugar->SelectedIndexChanged += gcnew EventHandler(this, &MainDashboardForm::OnCustomizationChanged);
            customizerPanel->Controls->Add(cmbSugar);

            // Ice Selector
            lblIce = gcnew Label();
            lblIce->Text = "Ice:";
            lblIce->Location = Point(283, 32);
            lblIce->AutoSize = true;
            lblIce->Font = gcnew System::Drawing::Font("Segoe UI", 8.5F);
            customizerPanel->Controls->Add(lblIce);

            cmbIce = gcnew ComboBox();
            cmbIce->Location = Point(310, 29);
            cmbIce->Size = System::Drawing::Size(75, 23);
            cmbIce->DropDownStyle = ComboBoxStyle::DropDownList;
            cmbIce->Font = gcnew System::Drawing::Font("Segoe UI", 8.5F);
            cmbIce->Items->AddRange(gcnew cli::array<Object^> { "Normal", "Less", "No Ice" });
            cmbIce->SelectedIndex = 0;
            cmbIce->SelectedIndexChanged += gcnew EventHandler(this, &MainDashboardForm::OnCustomizationChanged);
            customizerPanel->Controls->Add(cmbIce);

            // Extra Topping Checkbox
            chkExtraTopping = gcnew CheckBox();
            chkExtraTopping->Text = "+ Extra Topping (LKR 50.00)";
            chkExtraTopping->Location = Point(10, 60);
            chkExtraTopping->AutoSize = true;
            chkExtraTopping->Font = gcnew System::Drawing::Font("Segoe UI", 8.5F);
            chkExtraTopping->CheckedChanged += gcnew EventHandler(this, &MainDashboardForm::OnCustomizationChanged);
            customizerPanel->Controls->Add(chkExtraTopping);

            // Quantity Control
            lblQty = gcnew Label();
            lblQty->Text = "Qty:";
            lblQty->Location = Point(10, 92);
            lblQty->AutoSize = true;
            lblQty->Font = gcnew System::Drawing::Font("Segoe UI", 9.0F, FontStyle::Bold);
            customizerPanel->Controls->Add(lblQty);

            btnQtyMinus = gcnew Button();
            btnQtyMinus->Text = "-";
            btnQtyMinus->Location = Point(45, 87);
            btnQtyMinus->Size = System::Drawing::Size(32, 30);
            btnQtyMinus->Font = gcnew System::Drawing::Font("Segoe UI", 11.0F, FontStyle::Bold);
            btnQtyMinus->BackColor = Color::FromArgb(229, 231, 235);
            btnQtyMinus->FlatStyle = FlatStyle::Flat;
            btnQtyMinus->FlatAppearance->BorderSize = 0;
            btnQtyMinus->Cursor = Cursors::Hand;
            btnQtyMinus->Click += gcnew EventHandler(this, &MainDashboardForm::btnQtyMinus_Click);
            customizerPanel->Controls->Add(btnQtyMinus);

            lblQtyVal = gcnew Label();
            lblQtyVal->Text = "1";
            lblQtyVal->Location = Point(80, 91);
            lblQtyVal->Size = System::Drawing::Size(35, 22);
            lblQtyVal->TextAlign = ContentAlignment::MiddleCenter;
            lblQtyVal->Font = gcnew System::Drawing::Font("Segoe UI", 10.0F, FontStyle::Bold);
            customizerPanel->Controls->Add(lblQtyVal);

            btnQtyPlus = gcnew Button();
            btnQtyPlus->Text = "+";
            btnQtyPlus->Location = Point(118, 87);
            btnQtyPlus->Size = System::Drawing::Size(32, 30);
            btnQtyPlus->Font = gcnew System::Drawing::Font("Segoe UI", 11.0F, FontStyle::Bold);
            btnQtyPlus->BackColor = Color::FromArgb(229, 231, 235);
            btnQtyPlus->FlatStyle = FlatStyle::Flat;
            btnQtyPlus->FlatAppearance->BorderSize = 0;
            btnQtyPlus->Cursor = Cursors::Hand;
            btnQtyPlus->Click += gcnew EventHandler(this, &MainDashboardForm::btnQtyPlus_Click);
            customizerPanel->Controls->Add(btnQtyPlus);

            btnRemoveItem = gcnew Button();
            btnRemoveItem->Text = "Delete Item";
            btnRemoveItem->Location = Point(280, 87);
            btnRemoveItem->Size = System::Drawing::Size(105, 30);
            btnRemoveItem->BackColor = Color::FromArgb(225, 29, 72); // Rose Red
            btnRemoveItem->ForeColor = Color::White;
            btnRemoveItem->Font = gcnew System::Drawing::Font("Segoe UI", 8.5F, FontStyle::Bold);
            btnRemoveItem->FlatStyle = FlatStyle::Flat;
            btnRemoveItem->FlatAppearance->BorderSize = 0;
            btnRemoveItem->Cursor = Cursors::Hand;
            btnRemoveItem->Click += gcnew EventHandler(this, &MainDashboardForm::btnRemoveItem_Click);
            customizerPanel->Controls->Add(btnRemoveItem);

            rightTicketPanel->Controls->Add(customizerPanel);

            // Ticket Summary Panel
            ticketSummaryPanel = gcnew Panel();
            ticketSummaryPanel->Location = Point(15, 418);
            ticketSummaryPanel->Size = System::Drawing::Size(395, 240);
            ticketSummaryPanel->BackColor = Color::FromArgb(250, 250, 250);
            ticketSummaryPanel->BorderStyle = BorderStyle::FixedSingle;

            int sumY = 12;

            lblSubtotalTitle = gcnew Label();
            lblSubtotalTitle->Text = "Subtotal:";
            lblSubtotalTitle->Location = Point(15, sumY);
            lblSubtotalTitle->AutoSize = true;
            lblSubtotalTitle->Font = gcnew System::Drawing::Font("Segoe UI", 10.0F);
            lblSubtotalTitle->ForeColor = Color::FromArgb(107, 114, 128);
            ticketSummaryPanel->Controls->Add(lblSubtotalTitle);

            lblSubtotalVal = gcnew Label();
            lblSubtotalVal->Text = "LKR 0.00";
            lblSubtotalVal->Location = Point(260, sumY);
            lblSubtotalVal->Size = System::Drawing::Size(120, 22);
            lblSubtotalVal->TextAlign = ContentAlignment::MiddleRight;
            lblSubtotalVal->Font = gcnew System::Drawing::Font("Segoe UI", 10.0F, FontStyle::Bold);
            lblSubtotalVal->ForeColor = Color::FromArgb(33, 33, 33);
            ticketSummaryPanel->Controls->Add(lblSubtotalVal);

            sumY += 32;
            lblDiscountTitle = gcnew Label();
            lblDiscountTitle->Text = "Discount:";
            lblDiscountTitle->Location = Point(15, sumY);
            lblDiscountTitle->AutoSize = true;
            lblDiscountTitle->Font = gcnew System::Drawing::Font("Segoe UI", 9.5F);
            lblDiscountTitle->ForeColor = Color::FromArgb(107, 114, 128);
            ticketSummaryPanel->Controls->Add(lblDiscountTitle);

            cmbDiscount = gcnew ComboBox();
            cmbDiscount->Location = Point(245, sumY - 3);
            cmbDiscount->Size = System::Drawing::Size(135, 24);
            cmbDiscount->DropDownStyle = ComboBoxStyle::DropDownList;
            cmbDiscount->Items->AddRange(gcnew cli::array<Object^> { "0% None", "5% Discount", "10% Loyalty" });
            cmbDiscount->SelectedIndex = 0;
            cmbDiscount->SelectedIndexChanged += gcnew EventHandler(this, &MainDashboardForm::cmbDiscount_SelectedIndexChanged);
            ticketSummaryPanel->Controls->Add(cmbDiscount);

            sumY += 36;
            lblGrandTotalTitle = gcnew Label();
            lblGrandTotalTitle->Text = "TOTAL DUE:";
            lblGrandTotalTitle->Location = Point(15, sumY);
            lblGrandTotalTitle->AutoSize = true;
            lblGrandTotalTitle->Font = gcnew System::Drawing::Font("Segoe UI", 13.0F, FontStyle::Bold);
            lblGrandTotalTitle->ForeColor = Color::FromArgb(33, 33, 33);
            ticketSummaryPanel->Controls->Add(lblGrandTotalTitle);

            lblGrandTotalVal = gcnew Label();
            lblGrandTotalVal->Text = "LKR 0.00";
            lblGrandTotalVal->Location = Point(180, sumY);
            lblGrandTotalVal->Size = System::Drawing::Size(200, 28);
            lblGrandTotalVal->TextAlign = ContentAlignment::MiddleRight;
            lblGrandTotalVal->Font = gcnew System::Drawing::Font("Segoe UI", 15.0F, FontStyle::Bold);
            lblGrandTotalVal->ForeColor = Color::FromArgb(234, 88, 12); // Citrus Orange
            ticketSummaryPanel->Controls->Add(lblGrandTotalVal);

            // Large Full-Width Citrus Orange PAY Button
            btnPay = gcnew Button();
            btnPay->Text = "PAY   |   0 Items   |   LKR 0.00";
            btnPay->Location = Point(12, 172);
            btnPay->Size = System::Drawing::Size(370, 54);
            btnPay->BackColor = Color::FromArgb(255, 140, 0); // Fresh Citrus Orange (#FF8C00)
            btnPay->ForeColor = Color::White;
            btnPay->Font = gcnew System::Drawing::Font("Segoe UI", 12.5F, FontStyle::Bold);
            btnPay->FlatStyle = FlatStyle::Flat;
            btnPay->FlatAppearance->BorderSize = 0;
            btnPay->Cursor = Cursors::Hand;
            btnPay->Click += gcnew EventHandler(this, &MainDashboardForm::btnPay_Click);
            ticketSummaryPanel->Controls->Add(btnPay);

            rightTicketPanel->Controls->Add(ticketSummaryPanel);

            // ==========================================
            // 5. CENTER PRODUCT GRID
            // ==========================================
            centerPanel = gcnew Panel();
            centerPanel->Dock = DockStyle::Fill;
            centerPanel->BackColor = Color::FromArgb(248, 250, 248); // Fresh Soft Cream/Light

            flowDrinkCards = gcnew FlowLayoutPanel();
            flowDrinkCards->Dock = DockStyle::Fill;
            flowDrinkCards->AutoScroll = true;
            flowDrinkCards->WrapContents = true;
            flowDrinkCards->Padding = System::Windows::Forms::Padding(14, 14, 14, 14);
            flowDrinkCards->BackColor = Color::FromArgb(248, 250, 248);

            centerPanel->Controls->Add(flowDrinkCards);

            // ==========================================
            // DOCKING Z-ORDER (Standard WinForms Layout Hierarchy)
            // ==========================================
            // In WinForms, adding in reverse order guarantees:
            // 1. topNavPanel spans full width at the very top.
            // 2. bottomBarPanel spans full width at the bottom.
            // 3. leftCategoryPanel docks cleanly on the left between top & bottom.
            // 4. rightTicketPanel docks cleanly on the right between top & bottom.
            // 5. centerPanel fills the middle without ANY overlap or clipping!
            this->Controls->Add(centerPanel);
            this->Controls->Add(rightTicketPanel);
            this->Controls->Add(leftCategoryPanel);
            this->Controls->Add(bottomBarPanel);
            this->Controls->Add(topNavPanel);

            // Set initial active category highlight
            UpdateCategoryButtonStyles();
        }

        // ==========================================
        // SIDEBAR BUTTON BUILDER & HIGHLIGHT
        // ==========================================
        Button^ CreateCategoryButton(String^ text, int top) {
            Button^ btn = gcnew Button();
            btn->Text = text;
            btn->Location = Point(0, top);
            btn->Size = System::Drawing::Size(170, 54);
            btn->FlatStyle = FlatStyle::Flat;
            btn->FlatAppearance->BorderSize = 0;
            btn->Font = gcnew System::Drawing::Font("Segoe UI", 10.0F, FontStyle::Bold);
            btn->Cursor = Cursors::Hand;
            btn->TextAlign = ContentAlignment::MiddleLeft;
            btn->Padding = System::Windows::Forms::Padding(18, 0, 0, 0);
            btn->Click += gcnew EventHandler(this, &MainDashboardForm::OnCategoryButtonClick);
            return btn;
        }

        void UpdateCategoryButtonStyles() {
            cli::array<Button^>^ catButtons = gcnew cli::array<Button^> {
                btnCatAll, btnCatFresh, btnCatMilkshake, btnCatSmoothie, btnCatSpecial
            };

            for each (Button^ btn in catButtons) {
                if (btn->Text == activeCategory) {
                    btn->BackColor = Color::FromArgb(255, 140, 0); // Active Citrus Orange (#FF8C00)
                    btn->ForeColor = Color::White;
                } else {
                    btn->BackColor = Color::FromArgb(22, 56, 44); // Inactive Botanical Green
                    btn->ForeColor = Color::FromArgb(200, 230, 201); // Soft Mint Sage
                }
            }
        }

        void OnCategoryButtonClick(Object^ sender, EventArgs^ e) {
            Button^ clicked = dynamic_cast<Button^>(sender);
            if (clicked != nullptr) {
                activeCategory = clicked->Text;
                UpdateCategoryButtonStyles();
                PopulateDrinkCards();
            }
        }

        // ==========================================
        // PRODUCT CARDS GENERATOR
        // ==========================================
        void LoadCatalogFromDb() {
            try {
                catalogTable = DatabaseManager::GetInstance()->GetAllJuices();
                PopulateDrinkCards();
            } catch (Exception^) {
                // Safeguard against exceptions
            }
        }

        void PopulateDrinkCards() {
            if (catalogTable == nullptr) return;

            flowDrinkCards->SuspendLayout();
            flowDrinkCards->Controls->Clear();

            // Crucial fix: Reset scroll position to top so cards are NEVER covered or scrolled down!
            flowDrinkCards->AutoScrollPosition = Point(0, 0);

            String^ searchTerm = txtSearch->Text->Trim()->ToLower();

            for each (DataRow^ r in catalogTable->Rows) {
                String^ name = (r["name"] != DBNull::Value) ? r["name"]->ToString() : "";
                String^ cat = (r["category"] != DBNull::Value) ? r["category"]->ToString() : "";
                double price = (r["price"] != DBNull::Value) ? Convert::ToDouble(r["price"]) : 0.0;
                bool isSpecial = (r->Table->Columns->Contains("is_specialty") && r["is_specialty"] != DBNull::Value) 
                                 ? Convert::ToBoolean(r["is_specialty"]) : false;

                // Category Filter
                if (activeCategory == "Fresh Juices" && cat != "Fresh Juice") continue;
                if (activeCategory == "Milkshakes" && cat != "Milkshake") continue;
                if (activeCategory == "Smoothies" && cat != "Smoothie") continue;
                if (activeCategory == "Favorites" && !isSpecial) continue;

                // Search Filter
                if (!String::IsNullOrEmpty(searchTerm)) {
                    if (!name->ToLower()->Contains(searchTerm) && !cat->ToLower()->Contains(searchTerm)) {
                        continue;
                    }
                }

                // Create Card Panel (145px width fits perfectly 4 cards per row with 0 cut-off)
                Panel^ card = gcnew Panel();
                card->Size = System::Drawing::Size(145, 175);
                card->BackColor = Color::White;
                card->Margin = System::Windows::Forms::Padding(8);
                card->BorderStyle = BorderStyle::FixedSingle;
                card->Cursor = Cursors::Hand;
                card->Tag = r;

                // Bold Citrus Price Badge (Top Left, clearly visible)
                Label^ lblPrice = gcnew Label();
                lblPrice->Text = String::Format("LKR {0:F2}", price);
                lblPrice->Font = gcnew System::Drawing::Font("Segoe UI", 9.5F, FontStyle::Bold);
                lblPrice->ForeColor = Color::FromArgb(234, 88, 12); // Citrus Orange (#EA580C)
                lblPrice->Location = Point(8, 8);
                lblPrice->Size = System::Drawing::Size(128, 20);
                lblPrice->Tag = r;
                lblPrice->Click += gcnew EventHandler(this, &MainDashboardForm::OnDrinkCardClick);
                card->Controls->Add(lblPrice);

                // Drink Image
                PictureBox^ pic = gcnew PictureBox();
                pic->Location = Point(14, 30);
                pic->Size = System::Drawing::Size(116, 85);
                pic->SizeMode = PictureBoxSizeMode::Zoom;
                pic->Tag = r;
                pic->Click += gcnew EventHandler(this, &MainDashboardForm::OnDrinkCardClick);

                String^ imgPath = DatabaseManager::GetDrinkImageFile(name);
                if (System::IO::File::Exists(imgPath)) {
                    try {
                        System::IO::FileStream^ fs = gcnew System::IO::FileStream(imgPath, System::IO::FileMode::Open, System::IO::FileAccess::Read);
                        pic->Image = Image::FromStream(fs);
                        fs->Close();
                    } catch (Exception^) {
                        // Ignore image read failures safely
                    }
                }
                card->Controls->Add(pic);

                // Drink Title Label (Clean auto-wrap, no clipping)
                Label^ lblName = gcnew Label();
                lblName->Text = name;
                lblName->Font = gcnew System::Drawing::Font("Segoe UI", 9.0F, FontStyle::Bold);
                lblName->ForeColor = Color::FromArgb(31, 41, 55); // Dark Charcoal (#1F2937)
                lblName->Location = Point(6, 118);
                lblName->Size = System::Drawing::Size(133, 48);
                lblName->TextAlign = ContentAlignment::TopCenter;
                lblName->Tag = r;
                lblName->Click += gcnew EventHandler(this, &MainDashboardForm::OnDrinkCardClick);
                card->Controls->Add(lblName);

                // Wire click to panel container
                card->Click += gcnew EventHandler(this, &MainDashboardForm::OnDrinkCardClick);

                flowDrinkCards->Controls->Add(card);
            }

            // Ensure scroll is anchored at the top
            flowDrinkCards->AutoScrollPosition = Point(0, 0);
            flowDrinkCards->ResumeLayout();
        }

        void txtSearch_TextChanged(Object^ sender, EventArgs^ e) {
            PopulateDrinkCards();
        }

        // ==========================================
        // CARD CLICK & ORDER LOGIC (OOP CONCEPTS)
        // ==========================================
        void OnDrinkCardClick(Object^ sender, EventArgs^ e) {
            Control^ ctrl = dynamic_cast<Control^>(sender);
            if (ctrl == nullptr || ctrl->Tag == nullptr) return;

            DataRow^ row = dynamic_cast<DataRow^>(ctrl->Tag);
            if (row == nullptr) return;

            selectedJuiceRow = row;

            // Polymorphic Factory: Create concrete derived Juice object
            Juice^ juice = DatabaseManager::GetInstance()->CreateJuiceFromRow(row);
            if (juice == nullptr) return;

            // Check if this drink is already in the order cart (with Regular size)
            bool found = false;
            for (int i = 0; i < currentOrder->getItems()->Count; i++) {
                OrderItem^ itm = currentOrder->getItems()[i];
                if (itm->getJuice()->getId() == juice->getId() && itm->getSize() == "Regular") {
                    itm->setQuantity(itm->getQuantity() + 1);
                    found = true;
                    selectedCartIndex = i;
                    break;
                }
            }

            if (!found) {
                // Add new OrderItem: encapsulates drink, size, sugar, ice, and quantity
                OrderItem^ newItem = gcnew OrderItem(juice, 1, "Regular", "100% Normal", "Normal", false);
                currentOrder->addItem(newItem);
                selectedCartIndex = currentOrder->getItems()->Count - 1;
            }

            UpdateCartUI();
        }

        void UpdateCartUI() {
            gridCart->Rows->Clear();

            for (int i = 0; i < currentOrder->getItems()->Count; i++) {
                OrderItem^ itm = currentOrder->getItems()[i];
                gridCart->Rows->Add(
                    itm->getJuice()->getName(),
                    itm->getSize(),
                    itm->getQuantity(),
                    itm->getLineTotal().ToString("F2")
                );
            }

            if (selectedCartIndex >= 0 && selectedCartIndex < gridCart->Rows->Count) {
                gridCart->Rows[selectedCartIndex]->Selected = true;
                LoadSelectedCartItemDetails();
            } else if (gridCart->Rows->Count > 0) {
                gridCart->Rows[gridCart->Rows->Count - 1]->Selected = true;
                selectedCartIndex = gridCart->Rows->Count - 1;
                LoadSelectedCartItemDetails();
            } else {
                selectedCartIndex = -1;
                lblQtyVal->Text = "1";
            }

            double subtotal = currentOrder->calculateSubtotal();
            double grandTotal = currentOrder->getTotalAmount();
            int totalItems = 0;
            for each (OrderItem^ itm in currentOrder->getItems()) {
                totalItems += itm->getQuantity();
            }

            lblSubtotalVal->Text = String::Format("LKR {0:F2}", subtotal);
            lblGrandTotalVal->Text = String::Format("LKR {0:F2}", grandTotal);

            // Update Big Orange PAY bar text
            btnPay->Text = String::Format("PAY   |   {0} Items   |   LKR {1:F2}", totalItems, grandTotal);
        }

        void gridCart_SelectionChanged(Object^ sender, EventArgs^ e) {
            if (gridCart->SelectedRows->Count > 0) {
                selectedCartIndex = gridCart->SelectedRows[0]->Index;
                LoadSelectedCartItemDetails();
            }
        }

        void LoadSelectedCartItemDetails() {
            if (selectedCartIndex >= 0 && selectedCartIndex < currentOrder->getItems()->Count) {
                OrderItem^ itm = currentOrder->getItems()[selectedCartIndex];
                lblQtyVal->Text = itm->getQuantity().ToString();

                // Sync size combo
                if (itm->getSize() == "Medium") cmbSize->SelectedIndex = 1;
                else if (itm->getSize() == "Large") cmbSize->SelectedIndex = 2;
                else cmbSize->SelectedIndex = 0;

                // Sync sugar combo
                if (itm->getSugarLevel()->Contains("50%")) cmbSugar->SelectedIndex = 1;
                else if (itm->getSugarLevel()->Contains("No") || itm->getSugarLevel()->Contains("0%")) cmbSugar->SelectedIndex = 2;
                else cmbSugar->SelectedIndex = 0;

                // Sync ice combo
                if (itm->getIceLevel()->Contains("Less")) cmbIce->SelectedIndex = 1;
                else if (itm->getIceLevel()->Contains("No")) cmbIce->SelectedIndex = 2;
                else cmbIce->SelectedIndex = 0;

                chkExtraTopping->Checked = itm->getExtraTopping();
            }
        }

        void OnCustomizationChanged(Object^ sender, EventArgs^ e) {
            if (selectedCartIndex >= 0 && selectedCartIndex < currentOrder->getItems()->Count) {
                OrderItem^ itm = currentOrder->getItems()[selectedCartIndex];
                if (cmbSize->SelectedItem != nullptr) itm->setSize(cmbSize->SelectedItem->ToString());
                if (cmbSugar->SelectedItem != nullptr) itm->setSugarLevel(cmbSugar->SelectedItem->ToString());
                if (cmbIce->SelectedItem != nullptr) itm->setIceLevel(cmbIce->SelectedItem->ToString());
                itm->setExtraTopping(chkExtraTopping->Checked);
                UpdateCartUI();
            }
        }

        void btnQtyPlus_Click(Object^ sender, EventArgs^ e) {
            if (selectedCartIndex >= 0 && selectedCartIndex < currentOrder->getItems()->Count) {
                OrderItem^ itm = currentOrder->getItems()[selectedCartIndex];
                itm->setQuantity(itm->getQuantity() + 1);
                UpdateCartUI();
            }
        }

        void btnQtyMinus_Click(Object^ sender, EventArgs^ e) {
            if (selectedCartIndex >= 0 && selectedCartIndex < currentOrder->getItems()->Count) {
                OrderItem^ itm = currentOrder->getItems()[selectedCartIndex];
                if (itm->getQuantity() > 1) {
                    itm->setQuantity(itm->getQuantity() - 1);
                    UpdateCartUI();
                } else {
                    currentOrder->removeItemAt(selectedCartIndex);
                    selectedCartIndex = -1;
                    UpdateCartUI();
                }
            }
        }

        void btnRemoveItem_Click(Object^ sender, EventArgs^ e) {
            if (selectedCartIndex >= 0 && selectedCartIndex < currentOrder->getItems()->Count) {
                currentOrder->removeItemAt(selectedCartIndex);
                selectedCartIndex = -1;
                UpdateCartUI();
            } else {
                MessageBox::Show("Please select an item from the order ticket to delete.", "Notice",
                    MessageBoxButtons::OK, MessageBoxIcon::Information);
            }
        }

        void btnClearCart_Click(Object^ sender, EventArgs^ e) {
            currentOrder->clear();
            selectedCartIndex = -1;
            UpdateCartUI();
        }

        void cmbDiscount_SelectedIndexChanged(Object^ sender, EventArgs^ e) {
            double disc = 0.0;
            if (cmbDiscount->SelectedIndex == 1) disc = 5.0;
            else if (cmbDiscount->SelectedIndex == 2) disc = 10.0;
            currentOrder->setDiscountPercent(disc);
            UpdateCartUI();
        }

        // ==========================================
        // PAY & CHECKOUT MODAL
        // ==========================================
        void txtPayTender_TextChanged(Object^ sender, EventArgs^ e) {
            double cash = 0.0;
            Double::TryParse(txtPayTender->Text->Trim(), cash);
            double totalDue = currentOrder->getTotalAmount();
            double change = cash - totalDue;
            if (cash >= totalDue) {
                lblPayChange->ForeColor = Color::FromArgb(22, 101, 52); // Green
                lblPayChange->Text = String::Format("Change Due: LKR {0:F2}", change);
            } else {
                lblPayChange->ForeColor = Color::FromArgb(225, 29, 72); // Red
                lblPayChange->Text = String::Format("Shortage: -LKR {0:F2}", totalDue - cash);
            }
        }

        void btnPayConfirm_Click(Object^ sender, EventArgs^ e) {
            double cash = 0.0;
            double totalDue = currentOrder->getTotalAmount();
            if (!Double::TryParse(txtPayTender->Text->Trim(), cash) || cash < totalDue) {
                MessageBox::Show("Please enter a cash amount equal to or greater than the total bill.", "Payment Shortage",
                    MessageBoxButtons::OK, MessageBoxIcon::Warning);
                return;
            }

            currentOrder->setCustomerName(txtCustomer->Text->Trim());
            currentOrder->setOrderDate(DateTime::Now);
            currentOrder->processPayment(cash);

            // Save to Database
            int orderId = DatabaseManager::GetInstance()->SaveOrder(currentOrder);

            // Generate clean receipt
            String^ receipt = currentOrder->generateReceipt();

            if (dlgPay != nullptr) {
                dlgPay->Close();
            }

            // Display official receipt
            MessageBox::Show(receipt, String::Format("Juice Bar - Receipt #{0}", orderId),
                MessageBoxButtons::OK, MessageBoxIcon::Information);

            // Reset for next order
            currentOrder->clear();
            selectedCartIndex = -1;
            txtCustomer->Text = "Walk-in Customer";
            cmbDiscount->SelectedIndex = 0;
            UpdateCartUI();
        }

        void btnPay_Click(Object^ sender, EventArgs^ e) {
            if (currentOrder->getItemCount() == 0) {
                MessageBox::Show("Your order is empty! Please click on drinks from the menu to add items.", "Empty Order",
                    MessageBoxButtons::OK, MessageBoxIcon::Warning);
                return;
            }

            double totalDue = currentOrder->getTotalAmount();

            // Create clean payment dialog
            dlgPay = gcnew Form();
            dlgPay->Text = "Juice Bar - Payment Checkout";
            dlgPay->Size = System::Drawing::Size(440, 360);
            dlgPay->StartPosition = FormStartPosition::CenterParent;
            dlgPay->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedDialog;
            dlgPay->MaximizeBox = false;
            dlgPay->MinimizeBox = false;
            dlgPay->BackColor = Color::White;
            dlgPay->Font = gcnew System::Drawing::Font("Segoe UI", 9.5F);

            Label^ lblHead = gcnew Label();
            lblHead->Text = "Complete Order Payment";
            lblHead->Font = gcnew System::Drawing::Font("Segoe UI", 13.0F, FontStyle::Bold);
            lblHead->ForeColor = Color::FromArgb(22, 101, 52); // Fresh Green
            lblHead->Location = Point(25, 20);
            lblHead->AutoSize = true;
            dlgPay->Controls->Add(lblHead);

            Label^ lblTotalTitle = gcnew Label();
            lblTotalTitle->Text = "Total Amount Due:";
            lblTotalTitle->Location = Point(25, 65);
            lblTotalTitle->AutoSize = true;
            dlgPay->Controls->Add(lblTotalTitle);

            Label^ lblTotalAmt = gcnew Label();
            lblTotalAmt->Text = String::Format("LKR {0:F2}", totalDue);
            lblTotalAmt->Font = gcnew System::Drawing::Font("Segoe UI", 16.0F, FontStyle::Bold);
            lblTotalAmt->ForeColor = Color::FromArgb(234, 88, 12); // Citrus Orange
            lblTotalAmt->Location = Point(22, 88);
            lblTotalAmt->AutoSize = true;
            dlgPay->Controls->Add(lblTotalAmt);

            Label^ lblTender = gcnew Label();
            lblTender->Text = "Cash Tendered (LKR):";
            lblTender->Location = Point(25, 135);
            lblTender->AutoSize = true;
            dlgPay->Controls->Add(lblTender);

            txtPayTender = gcnew TextBox();
            txtPayTender->Text = totalDue.ToString("F2");
            txtPayTender->Font = gcnew System::Drawing::Font("Segoe UI", 12.0F);
            txtPayTender->Location = Point(25, 158);
            txtPayTender->Size = System::Drawing::Size(370, 29);
            txtPayTender->TextChanged += gcnew EventHandler(this, &MainDashboardForm::txtPayTender_TextChanged);
            dlgPay->Controls->Add(txtPayTender);

            lblPayChange = gcnew Label();
            lblPayChange->Text = "Change Due: LKR 0.00";
            lblPayChange->Font = gcnew System::Drawing::Font("Segoe UI", 10.5F, FontStyle::Bold);
            lblPayChange->ForeColor = Color::FromArgb(22, 101, 52);
            lblPayChange->Location = Point(25, 200);
            lblPayChange->AutoSize = true;
            dlgPay->Controls->Add(lblPayChange);

            Button^ btnConfirm = gcnew Button();
            btnConfirm->Text = "Confirm Payment & Print Receipt";
            btnConfirm->Location = Point(25, 245);
            btnConfirm->Size = System::Drawing::Size(370, 48);
            btnConfirm->BackColor = Color::FromArgb(255, 140, 0); // Citrus Orange
            btnConfirm->ForeColor = Color::White;
            btnConfirm->Font = gcnew System::Drawing::Font("Segoe UI", 11.5F, FontStyle::Bold);
            btnConfirm->FlatStyle = FlatStyle::Flat;
            btnConfirm->FlatAppearance->BorderSize = 0;
            btnConfirm->Cursor = Cursors::Hand;
            btnConfirm->Click += gcnew EventHandler(this, &MainDashboardForm::btnPayConfirm_Click);

            dlgPay->Controls->Add(btnConfirm);
            dlgPay->ShowDialog(this);
        }

        // ==========================================
        // NAVIGATION BUTTON HANDLERS
        // ==========================================
        void btnNavMenu_Click(Object^ sender, EventArgs^ e) {
            ManageMenuForm^ menuForm = gcnew ManageMenuForm();
            menuForm->ShowDialog();
            LoadCatalogFromDb();
        }

        void btnNavOrders_Click(Object^ sender, EventArgs^ e) {
            OrderHistoryForm^ ordersForm = gcnew OrderHistoryForm();
            ordersForm->ShowDialog();
        }

        void btnRefresh_Click(Object^ sender, EventArgs^ e) {
            LoadCatalogFromDb();
            MessageBox::Show("Juice catalog refreshed successfully.", "Juice Bar",
                MessageBoxButtons::OK, MessageBoxIcon::Information);
        }
    };
}
