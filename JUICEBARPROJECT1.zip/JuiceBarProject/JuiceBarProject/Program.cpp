#include <windows.h>
#include "MainDashboardForm.h"

// ==========================================================
// Rajarata University of Sri Lanka - Faculty of Applied Sciences
// Department of Computing - COM 1305 OOP Mini Project
// Application Entry Point (Windows Desktop GUI)
// ==========================================================

using namespace System;
using namespace System::Windows::Forms;

[STAThreadAttribute]
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    try {
        Application::EnableVisualStyles();
        Application::SetCompatibleTextRenderingDefault(false);

        JuiceBarProject::MainDashboardForm^ form = gcnew JuiceBarProject::MainDashboardForm();
        Application::Run(form);
    } catch (Exception^ ex) {
        MessageBox::Show(ex->ToString(), "Startup Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
    }
    return 0;
}
