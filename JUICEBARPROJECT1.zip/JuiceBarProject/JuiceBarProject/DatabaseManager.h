#pragma once
#include "AppIncludes.h"
#include "Juice.h"
#include "FreshJuice.h"
#include "MilkShake.h"
#include "Smoothie.h"
#include "Order.h"

// ==========================================================
// Rajarata University of Sri Lanka - Faculty of Applied Sciences
// Department of Computing - COM 1305 OOP Mini Project
// 
// DATABASE INTEGRATION REQUIREMENT:
// MySQL Database Connection & Full CRUD for 2+ Record Types
// Record Type 1: Juices (Menu Items) -> CREATE, READ, UPDATE, DELETE
// Record Type 2: Orders & Order Details -> CREATE, READ, UPDATE, DELETE
// ==========================================================

using namespace System;
using namespace System::Data;
using namespace System::Collections::Generic;
using namespace MySql::Data::MySqlClient;

namespace JuiceBarProject {

    /// <summary>
    /// Singleton/Manager class encapsulating all MySQL database CRUD transactions
    /// with graceful offline fallback.
    /// </summary>
    public ref class DatabaseManager {
    private:
        static DatabaseManager^ instance = nullptr;

        String^ server;
        int port;
        String^ databaseName;
        String^ username;
        String^ password;

        bool isConnected;
        String^ lastErrorMessage;
        // In-memory storage for orders
        DataTable^ fallbackOrdersTable;
        DataTable^ fallbackOrderItemsTable;
        int fallbackNextOrderId;

        bool dbInitialized;

        DatabaseManager() {
            // ==============================================================
            // MYSQL DATABASE CONNECTION CONFIGURATION
            // (Edit your MySQL server, port, database, user, and password here)
            // ==============================================================
            server = "localhost";
            port = 3306;
            databaseName = "juicebar_db";
            username = "root";
            password = "wagga@123"; // <--- Put your MySQL password here

            isConnected = false;
            lastErrorMessage = "";
            fallbackNextOrderId = 1;
            dbInitialized = false;

            setupFallbackData();
        }

        void setupFallbackData() {

            fallbackOrdersTable = gcnew DataTable("orders");
            fallbackOrdersTable->Columns->Add("id", int::typeid);
            fallbackOrdersTable->Columns->Add("customer_name", String::typeid);
            fallbackOrdersTable->Columns->Add("order_date", DateTime::typeid);
            fallbackOrdersTable->Columns->Add("total_amount", double::typeid);
            fallbackOrdersTable->Columns->Add("paid_amount", double::typeid);
            fallbackOrdersTable->Columns->Add("change_amount", double::typeid);
            fallbackOrdersTable->Columns->Add("status", String::typeid);

            // Seed sample order
            fallbackOrdersTable->Rows->Add(1, "Sahan Perera", DateTime::Now.AddHours(-2), 800.0, 1000.0, 200.0, "Completed");

            fallbackOrderItemsTable = gcnew DataTable("order_items");
            fallbackOrderItemsTable->Columns->Add("id", int::typeid);
            fallbackOrderItemsTable->Columns->Add("order_id", int::typeid);
            fallbackOrderItemsTable->Columns->Add("juice_id", int::typeid);
            fallbackOrderItemsTable->Columns->Add("item_name", String::typeid);
            fallbackOrderItemsTable->Columns->Add("category", String::typeid);
            fallbackOrderItemsTable->Columns->Add("size", String::typeid);
            fallbackOrderItemsTable->Columns->Add("sugar_level", String::typeid);
            fallbackOrderItemsTable->Columns->Add("ice_level", String::typeid);
            fallbackOrderItemsTable->Columns->Add("unit_price", double::typeid);
            fallbackOrderItemsTable->Columns->Add("quantity", int::typeid);
            fallbackOrderItemsTable->Columns->Add("subtotal", double::typeid);

            fallbackOrderItemsTable->Rows->Add(1, 1, 1, "Orange Juice", "Fresh Juice", "Regular", "100% Normal", "Normal Ice", 350.0, 1, 350.0);
            fallbackOrderItemsTable->Rows->Add(2, 1, 6, "Banana Smoothie", "Smoothie", "Regular", "50% Half Sugar", "Less Ice", 450.0, 1, 450.0);
            fallbackNextOrderId = 2;
        }

    public:
        static DatabaseManager^ GetInstance() {
            if (instance == nullptr) {
                instance = gcnew DatabaseManager();
            }
            return instance;
        }

        static String^ GetDrinkImageFile(String^ name) {
            String^ fileName = "default_drink.png";
            String^ lower = name != nullptr ? name->ToLower() : "";
            if (lower->Contains("orange")) fileName = "orange_juice.png";
            else if (lower->Contains("mango")) fileName = "mango_juice.png";
            else if (lower->Contains("pineapple")) fileName = "pineapple_juice.png";
            else if (lower->Contains("strawberr")) fileName = "strawberry_milkshake.png";
            else if (lower->Contains("chocolate") || lower->Contains("cocoa")) fileName = "chocolate_shake.png";
            else if (lower->Contains("banana")) fileName = "banana_smoothie.png";
            else if (lower->Contains("avocado")) fileName = "avocado_delight.png";
            else if (lower->Contains("passion")) fileName = "passion_fruit.png";
            else if (lower->Contains("lychee")) fileName = "lychee_juice.png";
            else if (lower->Contains("watermelon")) fileName = "watermelon_smoothie.png";
            else if (lower->Contains("coconut")) fileName = "coconut_smoothie.png";
            else if (lower->Contains("green") || lower->Contains("celery") || lower->Contains("detox")) fileName = "green_cleanser.png";

            // Check current directory
            String^ p1 = System::IO::Path::Combine("images", fileName);
            if (System::IO::File::Exists(p1)) return p1;

            // Check parent directory (1 level up)
            String^ p2 = System::IO::Path::Combine("..\\images", fileName);
            if (System::IO::File::Exists(p2)) return p2;

            // Check 2 levels up if needed
            String^ p3 = System::IO::Path::Combine("..\\..\\images", fileName);
            if (System::IO::File::Exists(p3)) return p3;

            // Check executable directory
            String^ baseDir = System::AppDomain::CurrentDomain->BaseDirectory;
            String^ p4 = System::IO::Path::Combine(baseDir, "images", fileName);
            if (System::IO::File::Exists(p4)) return p4;

            String^ p5 = System::IO::Path::Combine(baseDir, "..\\images", fileName);
            if (System::IO::File::Exists(p5)) return p5;

            return p1;
        }

        // Configuration
        void SetConnectionParameters(String^ srv, int prt, String^ db, String^ user, String^ pwd) {
            server = srv;
            port = prt;
            databaseName = db;
            username = user;
            password = pwd;
        }

        String^ GetServer() { return server; }
        int GetPort() { return port; }
        String^ GetDatabaseName() { return databaseName; }
        String^ GetUsername() { return username; }
        String^ GetPassword() { return password; }
        bool GetIsConnected() { return isConnected; }
        String^ GetLastErrorMessage() { return lastErrorMessage != nullptr ? lastErrorMessage : ""; }

        String^ BuildConnectionString(bool includeDatabase) {
            if (includeDatabase) {
                return String::Format("Server={0};Port={1};Database={2};Uid={3};Pwd={4};CharSet=utf8mb4;",
                    server, port, databaseName, username, password);
            } else {
                return String::Format("Server={0};Port={1};Uid={2};Pwd={3};CharSet=utf8mb4;",
                    server, port, username, password);
            }
        }

        // Test Connection
        bool TestConnection(String^% errorMessage) {
            errorMessage = "";
            try {
                String^ connStr = BuildConnectionString(false);
                MySqlConnection^ conn = gcnew MySqlConnection(connStr);
                conn->Open();
                conn->Close();
                isConnected = true;
                return true;
            } catch (Exception^ ex) {
                isConnected = false;
                errorMessage = ex->Message;
                return false;
            }
        }

        // Auto-Initialize MySQL Database & Tables
        bool InitializeDatabase(String^% outLog) {
            outLog = "";
            try {
                String^ serverConnStr = BuildConnectionString(false);
                MySqlConnection^ conn = gcnew MySqlConnection(serverConnStr);
                conn->Open();

                // 1. Create database if not exists
                MySqlCommand^ cmdDb = gcnew MySqlCommand(
                    String::Format("CREATE DATABASE IF NOT EXISTS `{0}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;", databaseName), conn);
                cmdDb->ExecuteNonQuery();
                conn->Close();

                // 2. Connect to specific database and create tables
                String^ dbConnStr = BuildConnectionString(true);
                conn = gcnew MySqlConnection(dbConnStr);
                conn->Open();

                // Juices Table (Record Type 1)
                String^ sqlJuices = 
                    "CREATE TABLE IF NOT EXISTS juices ("
                    "  id INT AUTO_INCREMENT PRIMARY KEY,"
                    "  name VARCHAR(100) NOT NULL,"
                    "  category VARCHAR(50) NOT NULL,"
                    "  price DOUBLE NOT NULL,"
                    "  description VARCHAR(255),"
                    "  fruit_type VARCHAR(100) DEFAULT '',"
                    "  milk_or_yogurt_type VARCHAR(100) DEFAULT '',"
                    "  is_specialty TINYINT(1) DEFAULT 0,"
                    "  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP"
                    ");";
                MySqlCommand^ cmdJuices = gcnew MySqlCommand(sqlJuices, conn);
                cmdJuices->ExecuteNonQuery();

                // Orders Table (Record Type 2)
                String^ sqlOrders = 
                    "CREATE TABLE IF NOT EXISTS orders ("
                    "  id INT AUTO_INCREMENT PRIMARY KEY,"
                    "  customer_name VARCHAR(100) NOT NULL,"
                    "  order_date DATETIME NOT NULL,"
                    "  total_amount DOUBLE NOT NULL,"
                    "  paid_amount DOUBLE NOT NULL,"
                    "  change_amount DOUBLE NOT NULL,"
                    "  status VARCHAR(50) NOT NULL DEFAULT 'Completed'"
                    ");";
                MySqlCommand^ cmdOrders = gcnew MySqlCommand(sqlOrders, conn);
                cmdOrders->ExecuteNonQuery();

                // Order Items Table
                String^ sqlItems = 
                    "CREATE TABLE IF NOT EXISTS order_items ("
                    "  id INT AUTO_INCREMENT PRIMARY KEY,"
                    "  order_id INT NOT NULL,"
                    "  juice_id INT,"
                    "  item_name VARCHAR(100) NOT NULL,"
                    "  category VARCHAR(50) NOT NULL,"
                    "  size VARCHAR(20) DEFAULT 'Regular',"
                    "  sugar_level VARCHAR(20) DEFAULT '100% Normal',"
                    "  ice_level VARCHAR(20) DEFAULT 'Normal Ice',"
                    "  unit_price DOUBLE NOT NULL,"
                    "  quantity INT NOT NULL,"
                    "  subtotal DOUBLE NOT NULL,"
                    "  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE"
                    ");";
                MySqlCommand^ cmdItems = gcnew MySqlCommand(sqlItems, conn);
                cmdItems->ExecuteNonQuery();

                // 3. Seed default juices if empty
                MySqlCommand^ countCmd = gcnew MySqlCommand("SELECT COUNT(*) FROM juices;", conn);
                long long rowCount = Convert::ToInt64(countCmd->ExecuteScalar());
                if (rowCount == 0) {
                    String^ seedSql = 
                        "INSERT INTO juices (name, category, price, description, fruit_type, milk_or_yogurt_type, is_specialty) VALUES "
                        "('Orange Juice', 'Fresh Juice', 350.00, 'Freshly squeezed sweet Valencia oranges', 'Orange', '', 0),"
                        "('Mango Juice', 'Fresh Juice', 400.00, 'Tropical ripe Karthacolomban mango pulp blend', 'Mango', '', 1),"
                        "('Pineapple Juice', 'Fresh Juice', 450.00, 'Zesty revitalizing fresh Ceylon pineapple nectar', 'Pineapple', '', 0),"
                        "('Strawberry Milkshake', 'Milkshake', 550.00, 'Creamy blend of whole milk, strawberry syrup, and vanilla gelato', 'Strawberry', 'Whole Milk', 1),"
                        "('Chocolate Shake', 'Milkshake', 580.00, 'Rich cocoa indulgence with chilled milk and gelato', 'Cocoa', 'Whole Milk', 0),"
                        "('Banana Smoothie', 'Smoothie', 450.00, 'Wholesome ripe Cavendish banana blended with creamy Greek yogurt', 'Banana', 'Greek Yogurt', 0),"
                        "('Avocado Delight', 'Smoothie', 600.00, 'Superfood avocado blended with wild honey and condensed nectar', 'Avocado', 'Low-Fat Yogurt', 1);";
                    MySqlCommand^ seedCmd = gcnew MySqlCommand(seedSql, conn);
                    seedCmd->ExecuteNonQuery();
                }

                conn->Close();
                isConnected = true;
                outLog = "Database 'juicebar_db' and tables initialized successfully!";
                return true;
            } catch (Exception^ ex) {
                outLog = "Database initialization error: " + ex->Message;
                return false;
            }
        }

        // ======================================================
        // RECORD TYPE 1: JUICES (MENU ITEMS) - FULL CRUD
        // ======================================================

        // CREATE: Add Juice (Exclusively to MySQL)
        bool AddJuice(String^ name, String^ category, double price, String^ desc, 
                      String^ fruitType, String^ milkOrYogurt, bool isSpecialty) {
            try {
                String^ connStr = BuildConnectionString(true);
                MySqlConnection^ conn = gcnew MySqlConnection(connStr);
                conn->Open();

                String^ query = "INSERT INTO juices (name, category, price, description, fruit_type, milk_or_yogurt_type, is_specialty) "
                                "VALUES (@name, @cat, @price, @desc, @fruit, @milk, @spec);";
                MySqlCommand^ cmd = gcnew MySqlCommand(query, conn);
                cmd->Parameters->AddWithValue("@name", name);
                cmd->Parameters->AddWithValue("@cat", category);
                cmd->Parameters->AddWithValue("@price", price);
                cmd->Parameters->AddWithValue("@desc", desc);
                cmd->Parameters->AddWithValue("@fruit", fruitType);
                cmd->Parameters->AddWithValue("@milk", milkOrYogurt);
                cmd->Parameters->AddWithValue("@spec", isSpecialty ? 1 : 0);
                int rows = cmd->ExecuteNonQuery();
                conn->Close();
                return rows > 0;
            } catch (Exception^ ex) {
                lastErrorMessage = ex->Message;
                return false;
            }
        }

        void EnsureDatabaseReady() {
            if (!dbInitialized) {
                String^ log = "";
                InitializeDatabase(log);
                dbInitialized = true;
            }
        }

        // READ: Get All Juices (Exclusively from MySQL)
        DataTable^ GetAllJuices() {
            EnsureDatabaseReady();

            try {
                String^ connStr = BuildConnectionString(true);
                MySqlConnection^ conn = gcnew MySqlConnection(connStr);
                conn->Open();

                String^ query = "SELECT id, name, category, price, description, fruit_type, milk_or_yogurt_type, is_specialty FROM juices ORDER BY id ASC;";
                MySqlDataAdapter^ adapter = gcnew MySqlDataAdapter(query, conn);
                DataTable^ dt = gcnew DataTable();
                adapter->Fill(dt);
                conn->Close();
                return dt;
            } catch (Exception^ ex) {
                lastErrorMessage = ex->Message;
                String^ hint = "";
                if (ex->Message != nullptr && ex->Message->Contains("Access denied")) {
                    hint = "\n\nTip: Access denied for MySQL user '" + username + "'.\n" +
                           "Please set your MySQL password in DatabaseManager.h (line 58).";
                }
                MessageBox::Show("Failed to connect to MySQL database or query 'juices' table:\n\n" + ex->Message + hint + "\n\nPlease ensure your MySQL server is running and the database is configured.",
                    "MySQL Database Error", MessageBoxButtons::OK, MessageBoxIcon::Error);

                // Return an empty table schema so controls binding to it do not crash
                DataTable^ emptyDt = gcnew DataTable("juices");
                emptyDt->Columns->Add("id", int::typeid);
                emptyDt->Columns->Add("name", String::typeid);
                emptyDt->Columns->Add("category", String::typeid);
                emptyDt->Columns->Add("price", double::typeid);
                emptyDt->Columns->Add("description", String::typeid);
                emptyDt->Columns->Add("fruit_type", String::typeid);
                emptyDt->Columns->Add("milk_or_yogurt_type", String::typeid);
                emptyDt->Columns->Add("is_specialty", bool::typeid);
                return emptyDt;
            }
        }

        // UPDATE: Edit Juice (Exclusively in MySQL)
        bool UpdateJuice(int id, String^ name, String^ category, double price, String^ desc,
                         String^ fruitType, String^ milkOrYogurt, bool isSpecialty) {
            try {
                String^ connStr = BuildConnectionString(true);
                MySqlConnection^ conn = gcnew MySqlConnection(connStr);
                conn->Open();

                String^ query = "UPDATE juices SET name=@name, category=@cat, price=@price, description=@desc, "
                                "fruit_type=@fruit, milk_or_yogurt_type=@milk, is_specialty=@spec WHERE id=@id;";
                MySqlCommand^ cmd = gcnew MySqlCommand(query, conn);
                cmd->Parameters->AddWithValue("@id", id);
                cmd->Parameters->AddWithValue("@name", name);
                cmd->Parameters->AddWithValue("@cat", category);
                cmd->Parameters->AddWithValue("@price", price);
                cmd->Parameters->AddWithValue("@desc", desc);
                cmd->Parameters->AddWithValue("@fruit", fruitType);
                cmd->Parameters->AddWithValue("@milk", milkOrYogurt);
                cmd->Parameters->AddWithValue("@spec", isSpecialty ? 1 : 0);
                int rows = cmd->ExecuteNonQuery();
                conn->Close();
                return rows > 0;
            } catch (Exception^ ex) {
                lastErrorMessage = ex->Message;
                return false;
            }
        }

        // DELETE: Remove Juice (Exclusively from MySQL)
        bool DeleteJuice(int id) {
            try {
                String^ connStr = BuildConnectionString(true);
                MySqlConnection^ conn = gcnew MySqlConnection(connStr);
                conn->Open();

                String^ query = "DELETE FROM juices WHERE id=@id;";
                MySqlCommand^ cmd = gcnew MySqlCommand(query, conn);
                cmd->Parameters->AddWithValue("@id", id);
                int rows = cmd->ExecuteNonQuery();
                conn->Close();
                return rows > 0;
            } catch (Exception^ ex) {
                lastErrorMessage = ex->Message;
                return false;
            }
        }

        // Helper: Convert DataRow to polymorphic Juice^ object
        Juice^ CreateJuiceFromRow(DataRow^ row) {
            int id = Convert::ToInt32(row["id"]);
            String^ name = row["name"]->ToString();
            String^ category = row["category"]->ToString();
            double price = Convert::ToDouble(row["price"]);
            String^ desc = row["description"] != DBNull::Value ? row["description"]->ToString() : "";
            String^ fruit = row->Table->Columns->Contains("fruit_type") && row["fruit_type"] != DBNull::Value ? row["fruit_type"]->ToString() : name;
            String^ milk = row->Table->Columns->Contains("milk_or_yogurt_type") && row["milk_or_yogurt_type"] != DBNull::Value ? row["milk_or_yogurt_type"]->ToString() : "Whole Milk";
            bool specialty = row->Table->Columns->Contains("is_specialty") && row["is_specialty"] != DBNull::Value ? Convert::ToBoolean(row["is_specialty"]) : false;

            if (category == "Fresh Juice") {
                return gcnew FreshJuice(id, name, price, desc, fruit, specialty, "Normal");
            } else if (category == "Milkshake") {
                return gcnew MilkShake(id, name, price, desc, milk, "Vanilla Gelato", specialty ? 1 : 0);
            } else {
                return gcnew Smoothie(id, name, price, desc, milk, specialty, "Chia Seeds");
            }
        }

        // ======================================================
        // RECORD TYPE 2: ORDERS & ORDER ITEMS - FULL CRUD
        // ======================================================

        // CREATE: Place & Save Order
        int SaveOrder(Order^ order) {
            try {
                String^ connStr = BuildConnectionString(true);
                MySqlConnection^ conn = gcnew MySqlConnection(connStr);
                conn->Open();

                // Insert into orders
                String^ orderSql = "INSERT INTO orders (customer_name, order_date, total_amount, paid_amount, change_amount, status) "
                                   "VALUES (@cust, @date, @total, @paid, @change, @st); SELECT LAST_INSERT_ID();";
                MySqlCommand^ cmd = gcnew MySqlCommand(orderSql, conn);
                cmd->Parameters->AddWithValue("@cust", order->getCustomerName());
                cmd->Parameters->AddWithValue("@date", order->getOrderDate());
                cmd->Parameters->AddWithValue("@total", order->getTotalAmount());
                cmd->Parameters->AddWithValue("@paid", order->getPaidAmount());
                cmd->Parameters->AddWithValue("@change", order->getChangeAmount());
                cmd->Parameters->AddWithValue("@st", order->getStatus());

                int generatedOrderId = Convert::ToInt32(cmd->ExecuteScalar());
                order->setOrderId(generatedOrderId);

                // Insert line items
                for each (OrderItem^ itm in order->getItems()) {
                    String^ itemSql = "INSERT INTO order_items (order_id, juice_id, item_name, category, size, sugar_level, ice_level, unit_price, quantity, subtotal) "
                                      "VALUES (@oid, @jid, @name, @cat, @size, @sugar, @ice, @unit, @qty, @sub);";
                    MySqlCommand^ itmCmd = gcnew MySqlCommand(itemSql, conn);
                    itmCmd->Parameters->AddWithValue("@oid", generatedOrderId);
                    itmCmd->Parameters->AddWithValue("@jid", itm->getJuice()->getId());
                    itmCmd->Parameters->AddWithValue("@name", itm->getJuice()->getName());
                    itmCmd->Parameters->AddWithValue("@cat", itm->getJuice()->getCategoryName());
                    itmCmd->Parameters->AddWithValue("@size", itm->getSize());
                    itmCmd->Parameters->AddWithValue("@sugar", itm->getSugarLevel());
                    itmCmd->Parameters->AddWithValue("@ice", itm->getIceLevel());
                    itmCmd->Parameters->AddWithValue("@unit", itm->getUnitPrice());
                    itmCmd->Parameters->AddWithValue("@qty", itm->getQuantity());
                    itmCmd->Parameters->AddWithValue("@sub", itm->getLineTotal());
                    itmCmd->ExecuteNonQuery();
                }

                conn->Close();
                return generatedOrderId;
            } catch (Exception^) {
                // In-memory fallback
                int genId = fallbackNextOrderId++;
                order->setOrderId(genId);
                fallbackOrdersTable->Rows->Add(genId, order->getCustomerName(), order->getOrderDate(),
                    order->getTotalAmount(), order->getPaidAmount(), order->getChangeAmount(), order->getStatus());

                for each (OrderItem^ itm in order->getItems()) {
                    int itmId = fallbackOrderItemsTable->Rows->Count + 1;
                    fallbackOrderItemsTable->Rows->Add(itmId, genId, itm->getJuice()->getId(),
                        itm->getJuice()->getName(), itm->getJuice()->getCategoryName(),
                        itm->getSize(), itm->getSugarLevel(), itm->getIceLevel(),
                        itm->getUnitPrice(), itm->getQuantity(), itm->getLineTotal());
                }
                return genId;
            }
        }

        // READ: Get All Orders
        DataTable^ GetAllOrders() {
            try {
                String^ connStr = BuildConnectionString(true);
                MySqlConnection^ conn = gcnew MySqlConnection(connStr);
                conn->Open();

                String^ query = "SELECT id, customer_name, order_date, total_amount, paid_amount, change_amount, status FROM orders ORDER BY id DESC;";
                MySqlDataAdapter^ adapter = gcnew MySqlDataAdapter(query, conn);
                DataTable^ dt = gcnew DataTable();
                adapter->Fill(dt);
                conn->Close();
                return dt;
            } catch (Exception^) {
                return fallbackOrdersTable;
            }
        }

        // READ: Get Items for a Specific Order
        DataTable^ GetOrderItems(int orderId) {
            try {
                String^ connStr = BuildConnectionString(true);
                MySqlConnection^ conn = gcnew MySqlConnection(connStr);
                conn->Open();

                String^ query = "SELECT id, order_id, item_name, category, size, sugar_level, ice_level, unit_price, quantity, subtotal "
                                "FROM order_items WHERE order_id=@oid;";
                MySqlCommand^ cmd = gcnew MySqlCommand(query, conn);
                cmd->Parameters->AddWithValue("@oid", orderId);

                MySqlDataAdapter^ adapter = gcnew MySqlDataAdapter(cmd);
                DataTable^ dt = gcnew DataTable();
                adapter->Fill(dt);
                conn->Close();
                return dt;
            } catch (Exception^) {
                DataTable^ filtered = fallbackOrderItemsTable->Clone();
                for each (DataRow^ r in fallbackOrderItemsTable->Rows) {
                    if (Convert::ToInt32(r["order_id"]) == orderId) {
                        filtered->ImportRow(r);
                    }
                }
                return filtered;
            }
        }

        // UPDATE: Update Order Status
        bool UpdateOrderStatus(int orderId, String^ newStatus) {
            try {
                String^ connStr = BuildConnectionString(true);
                MySqlConnection^ conn = gcnew MySqlConnection(connStr);
                conn->Open();

                String^ query = "UPDATE orders SET status=@st WHERE id=@id;";
                MySqlCommand^ cmd = gcnew MySqlCommand(query, conn);
                cmd->Parameters->AddWithValue("@id", orderId);
                cmd->Parameters->AddWithValue("@st", newStatus);
                cmd->ExecuteNonQuery();
                conn->Close();
                return true;
            } catch (Exception^) {
                for each (DataRow^ r in fallbackOrdersTable->Rows) {
                    if (Convert::ToInt32(r["id"]) == orderId) {
                        r["status"] = newStatus;
                        return true;
                    }
                }
                return false;
            }
        }

        // DELETE: Delete Order Record (Cascading)
        bool DeleteOrder(int orderId) {
            try {
                String^ connStr = BuildConnectionString(true);
                MySqlConnection^ conn = gcnew MySqlConnection(connStr);
                conn->Open();

                // Foreign key constraint CASCADE deletes items, but for robustness:
                MySqlCommand^ cmdItm = gcnew MySqlCommand("DELETE FROM order_items WHERE order_id=@oid;", conn);
                cmdItm->Parameters->AddWithValue("@oid", orderId);
                cmdItm->ExecuteNonQuery();

                MySqlCommand^ cmdOrd = gcnew MySqlCommand("DELETE FROM orders WHERE id=@id;", conn);
                cmdOrd->Parameters->AddWithValue("@id", orderId);
                cmdOrd->ExecuteNonQuery();

                conn->Close();
                return true;
            } catch (Exception^) {
                for (int i = 0; i < fallbackOrdersTable->Rows->Count; i++) {
                    if (Convert::ToInt32(fallbackOrdersTable->Rows[i]["id"]) == orderId) {
                        fallbackOrdersTable->Rows->RemoveAt(i);
                        break;
                    }
                }
                for (int i = fallbackOrderItemsTable->Rows->Count - 1; i >= 0; i--) {
                    if (Convert::ToInt32(fallbackOrderItemsTable->Rows[i]["order_id"]) == orderId) {
                        fallbackOrderItemsTable->Rows->RemoveAt(i);
                    }
                }
                return true;
            }
        }

        // Sales Analytics & Summary Stats
        void GetSalesStatistics(double% totalRevenue, int% totalOrders, int% totalJuicesSold) {
            totalRevenue = 0.0;
            totalOrders = 0;
            totalJuicesSold = 0;

            try {
                String^ connStr = BuildConnectionString(true);
                MySqlConnection^ conn = gcnew MySqlConnection(connStr);
                conn->Open();

                MySqlCommand^ cmd1 = gcnew MySqlCommand("SELECT IFNULL(SUM(total_amount), 0), COUNT(*) FROM orders WHERE status='Completed';", conn);
                MySqlDataReader^ reader1 = cmd1->ExecuteReader();
                if (reader1->Read()) {
                    totalRevenue = Convert::ToDouble(reader1[0]);
                    totalOrders = Convert::ToInt32(reader1[1]);
                }
                reader1->Close();

                MySqlCommand^ cmd2 = gcnew MySqlCommand("SELECT IFNULL(SUM(quantity), 0) FROM order_items;", conn);
                Object^ obj = cmd2->ExecuteScalar();
                if (obj != nullptr && obj != DBNull::Value) {
                    totalJuicesSold = Convert::ToInt32(obj);
                }
                conn->Close();
            } catch (Exception^) {
                // Fallback calculations
                for each (DataRow^ r in fallbackOrdersTable->Rows) {
                    if (r["status"]->ToString() == "Completed") {
                        totalRevenue += Convert::ToDouble(r["total_amount"]);
                        totalOrders++;
                    }
                }
                for each (DataRow^ r in fallbackOrderItemsTable->Rows) {
                    totalJuicesSold += Convert::ToInt32(r["quantity"]);
                }
            }
        }
    };
}
