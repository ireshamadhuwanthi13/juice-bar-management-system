#pragma once

#include "Juice.h"

// ==========================================================
// Rajarata University of Sri Lanka - Faculty of Applied Sciences
// Department of Computing - COM 1305 OOP Mini Project
// 
// OOP CONCEPTS DEMONSTRATED:
// 1. INHERITANCE: Inherits from abstract base class Juice
// 2. POLYMORPHISM: Specialized price calculation with dairy/ice-cream toppings
// 3. ENCAPSULATION: Milk type, gelato flavors, scoop counts
// ==========================================================

namespace JuiceBarProject {

    /// <summary>
    /// Derived class representing Milkshakes.
    /// Demonstrates INHERITANCE and RUNTIME POLYMORPHISM.
    /// </summary>
    public ref class MilkShake : public Juice {
    private:
        String^ milkType;        // e.g. "Whole Fresh Milk", "Almond Milk", "Oat Milk"
        String^ iceCreamFlavor;  // e.g. "Vanilla Gelato", "Chocolate", "Strawberry"
        int extraScoops;

    public:
        MilkShake(int id, String^ name, double basePrice, String^ description,
                  String^ milkType, String^ iceCreamFlavor, int extraScoops)
            : Juice(id, name, basePrice, "Milkshake", description) {
            this->milkType = milkType;
            this->iceCreamFlavor = iceCreamFlavor;
            setExtraScoops(extraScoops);
        }

        // Encapsulation: Specialized Getters and Setters
        String^ getMilkType() {
            return milkType;
        }

        void setMilkType(String^ value) {
            milkType = value;
        }

        String^ getIceCreamFlavor() {
            return iceCreamFlavor;
        }

        void setIceCreamFlavor(String^ value) {
            iceCreamFlavor = value;
        }

        int getExtraScoops() {
            return extraScoops;
        }

        void setExtraScoops(int value) {
            if (value >= 0) {
                extraScoops = value;
            } else {
                extraScoops = 0;
            }
        }

        // ------------------------------------------------------
        // RUNTIME POLYMORPHISM: Specialized Pricing Calculation
        // ------------------------------------------------------
        virtual double calculatePrice(int quantity, String^ size, bool extraTopping) override {
            double unitPrice = basePrice;

            if (size == "Medium") {
                unitPrice *= 1.25;
            } else if (size == "Large") {
                unitPrice *= 1.50;
            }

            // Dairy & Plant milk premium
            if (milkType == "Almond Milk" || milkType == "Oat Milk") {
                unitPrice += 70.0;
            }

            // Extra scoops
            unitPrice += (extraScoops * 80.0);

            // Extra topping: Whipped cream & caramel/chocolate drizzle
            if (extraTopping) {
                unitPrice += 50.0;
            }

            return unitPrice * quantity;
        }

        virtual String^ getPreparationDetails() override {
            return String::Format("Milk: {0} | Ice Cream: {1} | Extra Scoops: {2}",
                milkType, iceCreamFlavor, extraScoops);
        }

        virtual String^ getCategoryName() override {
            return "Milkshake";
        }
    };
}
