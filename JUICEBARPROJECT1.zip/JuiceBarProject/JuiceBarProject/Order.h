#pragma once

#include "OrderItem.h"

// ==========================================================
// Rajarata University of Sri Lanka - Faculty of Applied Sciences
// Department of Computing - COM 1305 OOP Mini Project
// 
// OOP CONCEPTS DEMONSTRATED:
// 1. CLASS & OBJECT: Order encapsulates full customer transaction & cart
// 2. ENCAPSULATION: Items list, subtotal, payment verification & change computation
// 3. COMPILE-TIME POLYMORPHISM: Method overloading (addItem)
// ==========================================================

using namespace System::Collections::Generic;

namespace JuiceBarProject {

    /// <summary>
    /// Represents a complete Customer Order transaction.
    /// Demonstrates ENCAPSULATION, COMPOSITION, and METHOD OVERLOADING.
    /// </summary>
    public ref class Order {
    private:
        int orderId;
        String^ customerName;
        DateTime orderDate;
        List<OrderItem^>^ items;
        double discountPercent;
        double totalAmount;
        double paidAmount;
        double changeAmount;
        String^ status; // "Completed", "Pending", "Cancelled"

    public:
        // Default Constructor
        Order() {
            this->orderId = 0;
            this->customerName = "Walk-in Customer";
            this->orderDate = DateTime::Now;
            this->items = gcnew List<OrderItem^>();
            this->discountPercent = 0.0;
            this->totalAmount = 0.0;
            this->paidAmount = 0.0;
            this->changeAmount = 0.0;
            this->status = "Pending";
        }

        // Parameterized Constructor
        Order(String^ customer) {
            this->orderId = 0;
            setCustomerName(customer);
            this->orderDate = DateTime::Now;
            this->items = gcnew List<OrderItem^>();
            this->discountPercent = 0.0;
            this->totalAmount = 0.0;
            this->paidAmount = 0.0;
            this->changeAmount = 0.0;
            this->status = "Pending";
        }

        // ------------------------------------------------------
        // ENCAPSULATION: Accessors & Mutators
        // ------------------------------------------------------
        int getOrderId() {
            return orderId;
        }

        void setOrderId(int id) {
            orderId = id;
        }

        String^ getCustomerName() {
            return customerName;
        }

        void setCustomerName(String^ name) {
            if (!String::IsNullOrWhiteSpace(name)) {
                customerName = name->Trim();
            } else {
                customerName = "Walk-in Customer";
            }
        }

        DateTime getOrderDate() {
            return orderDate;
        }

        void setOrderDate(DateTime dt) {
            orderDate = dt;
        }

        List<OrderItem^>^ getItems() {
            return items;
        }

        double getDiscountPercent() {
            return discountPercent;
        }

        void setDiscountPercent(double disc) {
            if (disc >= 0.0 && disc <= 100.0) {
                discountPercent = disc;
            } else {
                discountPercent = 0.0;
            }
            calculateTotals();
        }

        double getTotalAmount() {
            return totalAmount;
        }

        void setTotalAmount(double amt) {
            totalAmount = amt;
        }

        double getPaidAmount() {
            return paidAmount;
        }

        double getChangeAmount() {
            return changeAmount;
        }

        String^ getStatus() {
            return status;
        }

        void setStatus(String^ st) {
            status = st;
        }

        // ------------------------------------------------------
        // COMPILE-TIME POLYMORPHISM: Method Overloading (addItem)
        // ------------------------------------------------------
        // Overload 1: Adding fully configured OrderItem object
        void addItem(OrderItem^ item) {
            if (item != nullptr) {
                items->Add(item);
                calculateTotals();
            }
        }

        // Overload 2: Convenience overload with basic parameters
        void addItem(Juice^ juice, int quantity) {
            if (juice != nullptr && quantity > 0) {
                OrderItem^ item = gcnew OrderItem(juice, quantity, "Regular", "100% Normal", "Normal Ice", false);
                items->Add(item);
                calculateTotals();
            }
        }

        // Overload 3: Adding with size and extra topping specification
        void addItem(Juice^ juice, int quantity, String^ size, bool extraTopping) {
            if (juice != nullptr && quantity > 0) {
                OrderItem^ item = gcnew OrderItem(juice, quantity, size, "100% Normal", "Normal Ice", extraTopping);
                items->Add(item);
                calculateTotals();
            }
        }

        void removeItemAt(int index) {
            if (index >= 0 && index < items->Count) {
                items->RemoveAt(index);
                calculateTotals();
            }
        }

        void clear() {
            items->Clear();
            totalAmount = 0.0;
            paidAmount = 0.0;
            changeAmount = 0.0;
        }

        int getItemCount() {
            return items->Count;
        }

        // ------------------------------------------------------
        // Financial Calculations
        // ------------------------------------------------------
        double calculateSubtotal() {
            double sub = 0.0;
            for each (OrderItem^ itm in items) {
                sub += itm->getLineTotal();
            }
            return sub;
        }

        void calculateTotals() {
            double sub = calculateSubtotal();
            double discountVal = sub * (discountPercent / 100.0);
            totalAmount = sub - discountVal;
            if (totalAmount < 0.0) totalAmount = 0.0;

            if (paidAmount > 0.0) {
                changeAmount = paidAmount - totalAmount;
            } else {
                changeAmount = 0.0;
            }
        }

        bool processPayment(double payment) {
            paidAmount = payment;
            calculateTotals();
            if (paidAmount >= totalAmount) {
                changeAmount = paidAmount - totalAmount;
                status = "Completed";
                return true;
            }
            return false;
        }

        // ------------------------------------------------------
        // Bill / Receipt Generation
        // ------------------------------------------------------
        String^ generateReceipt() {
            System::Text::StringBuilder^ sb = gcnew System::Text::StringBuilder();
            sb->AppendLine("==================================================");
            sb->AppendLine("                  Juice Bar                       ");
            sb->AppendLine("               PREMIUM BEVERAGES                  ");
            sb->AppendLine("==================================================");
            sb->AppendLine(String::Format(" Date / Time: {0}", orderDate.ToString("yyyy-MM-dd HH:mm:ss")));
            sb->AppendLine(String::Format(" Customer   : {0}", customerName));
            sb->AppendLine(String::Format(" Status     : {0}", status));
            sb->AppendLine("--------------------------------------------------");
            sb->AppendLine(String::Format("{0,-20} {1,5} {2,10} {3,10}", "Item", "Qty", "Price", "Total"));
            sb->AppendLine("--------------------------------------------------");

            for each (OrderItem^ itm in items) {
                String^ name = itm->getJuice()->getName();
                if (name->Length > 19) name = name->Substring(0, 19);
                sb->AppendLine(String::Format("{0,-20} {1,5} {2,10:F2} {3,10:F2}",
                    name, itm->getQuantity(), itm->getUnitPrice(), itm->getLineTotal()));
                sb->AppendLine(String::Format("   [{0} | {1} | {2}]",
                    itm->getSize(), itm->getSugarLevel(), itm->getIceLevel()));
            }

            sb->AppendLine("--------------------------------------------------");
            sb->AppendLine(String::Format(" Subtotal           : LKR {0:F2}", calculateSubtotal()));
            if (discountPercent > 0.0) {
                sb->AppendLine(String::Format(" Discount ({0:F0}%)     : -LKR {1:F2}",
                    discountPercent, calculateSubtotal() * (discountPercent / 100.0)));
            }
            sb->AppendLine(String::Format(" TOTAL AMOUNT       : LKR {0:F2}", totalAmount));
            sb->AppendLine(String::Format(" Paid Amount        : LKR {0:F2}", paidAmount));
            sb->AppendLine(String::Format(" Change Due         : LKR {0:F2}", changeAmount));
            sb->AppendLine("==================================================");
            sb->AppendLine("          THANK YOU FOR VISITING US!             ");
            sb->AppendLine("           PLEASE ENJOY YOUR DRINK!               ");
            sb->AppendLine("==================================================");
            return sb->ToString();
        }
    };
}
