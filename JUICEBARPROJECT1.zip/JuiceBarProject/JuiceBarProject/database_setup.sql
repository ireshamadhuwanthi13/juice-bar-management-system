-- ==========================================================
-- Rajarata University of Sri Lanka - Faculty of Applied Sciences
-- Department of Computing
-- COM 1305 — Object Oriented Programming Mini Project
-- Project: Juice Bar Management System
-- Database Setup Script (MySQL)
-- ==========================================================

CREATE DATABASE IF NOT EXISTS juicebar_db;
USE juicebar_db;

-- ----------------------------------------------------------
-- Table 1: juices (Menu Items / Products - Record Type 1)
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS juices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL,
    price DOUBLE NOT NULL,
    description VARCHAR(255),
    fruit_type VARCHAR(100) DEFAULT '',
    milk_or_yogurt_type VARCHAR(100) DEFAULT '',
    is_specialty TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ----------------------------------------------------------
-- Table 2: orders (Customer Orders - Record Type 2)
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    order_date DATETIME NOT NULL,
    total_amount DOUBLE NOT NULL,
    paid_amount DOUBLE NOT NULL,
    change_amount DOUBLE NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'Completed'
);

-- ----------------------------------------------------------
-- Table 3: order_items (Detailed Line Items linked to Orders)
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    juice_id INT,
    item_name VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL,
    size VARCHAR(20) DEFAULT 'Regular',
    sugar_level VARCHAR(20) DEFAULT '100% Normal',
    ice_level VARCHAR(20) DEFAULT 'Normal Ice',
    unit_price DOUBLE NOT NULL,
    quantity INT NOT NULL,
    subtotal DOUBLE NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
);

-- ----------------------------------------------------------
-- Default Seed Data (Initial Menu Items)
-- ----------------------------------------------------------
INSERT INTO juices (name, category, price, description, fruit_type, milk_or_yogurt_type, is_specialty)
SELECT 'Orange Juice', 'Fresh Juice', 350.00, 'Freshly squeezed sweet Valencia oranges rich in Vitamin C', 'Orange', '', 0
WHERE NOT EXISTS (SELECT 1 FROM juices WHERE name = 'Orange Juice');

INSERT INTO juices (name, category, price, description, fruit_type, milk_or_yogurt_type, is_specialty)
SELECT 'Mango Juice', 'Fresh Juice', 400.00, 'Luscious tropical ripe Karthacolomban mango pulp blend', 'Mango', '', 1
WHERE NOT EXISTS (SELECT 1 FROM juices WHERE name = 'Mango Juice');

INSERT INTO juices (name, category, price, description, fruit_type, milk_or_yogurt_type, is_specialty)
SELECT 'Pineapple Juice', 'Fresh Juice', 450.00, 'Zesty revitalizing fresh Ceylon pineapple nectar', 'Pineapple', '', 0
WHERE NOT EXISTS (SELECT 1 FROM juices WHERE name = 'Pineapple Juice');

INSERT INTO juices (name, category, price, description, fruit_type, milk_or_yogurt_type, is_specialty)
SELECT 'Strawberry Milkshake', 'Milkshake', 550.00, 'Creamy blend of whole milk, strawberry syrup, and vanilla ice cream', 'Strawberry', 'Whole Milk', 1
WHERE NOT EXISTS (SELECT 1 FROM juices WHERE name = 'Strawberry Milkshake');

INSERT INTO juices (name, category, price, description, fruit_type, milk_or_yogurt_type, is_specialty)
SELECT 'Chocolate Shake', 'Milkshake', 580.00, 'Rich cocoa indulgence with chilled milk and chocolate gelato', 'Cocoa', 'Whole Milk', 0
WHERE NOT EXISTS (SELECT 1 FROM juices WHERE name = 'Chocolate Shake');

INSERT INTO juices (name, category, price, description, fruit_type, milk_or_yogurt_type, is_specialty)
SELECT 'Banana Smoothie', 'Smoothie', 450.00, 'Wholesome ripe Cavendish banana blended with creamy Greek yogurt', 'Banana', 'Greek Yogurt', 0
WHERE NOT EXISTS (SELECT 1 FROM juices WHERE name = 'Banana Smoothie');

INSERT INTO juices (name, category, price, description, fruit_type, milk_or_yogurt_type, is_specialty)
SELECT 'Avocado Delight', 'Smoothie', 600.00, 'Superfood avocado blended with honey and condensed milk nectar', 'Avocado', 'Low-Fat Yogurt', 1
WHERE NOT EXISTS (SELECT 1 FROM juices WHERE name = 'Avocado Delight');

-- ----------------------------------------------------------
-- Sample Order Data (For Initial Testing & Reports)
-- ----------------------------------------------------------
INSERT INTO orders (customer_name, order_date, total_amount, paid_amount, change_amount, status)
SELECT 'Sahan Perera', NOW() - INTERVAL 2 HOUR, 800.00, 1000.00, 200.00, 'Completed'
WHERE NOT EXISTS (SELECT 1 FROM orders WHERE customer_name = 'Sahan Perera');

INSERT INTO order_items (order_id, juice_id, item_name, category, size, sugar_level, ice_level, unit_price, quantity, subtotal)
SELECT 1, 1, 'Orange Juice', 'Fresh Juice', 'Regular', '100% Normal', 'Normal Ice', 350.00, 1, 350.00
WHERE EXISTS (SELECT 1 FROM orders WHERE id = 1) AND NOT EXISTS (SELECT 1 FROM order_items WHERE order_id = 1 AND juice_id = 1);

INSERT INTO order_items (order_id, juice_id, item_name, category, size, sugar_level, ice_level, unit_price, quantity, subtotal)
SELECT 1, 6, 'Banana Smoothie', 'Smoothie', 'Regular', '50% Half Sugar', 'Less Ice', 450.00, 1, 450.00
WHERE EXISTS (SELECT 1 FROM orders WHERE id = 1) AND NOT EXISTS (SELECT 1 FROM order_items WHERE order_id = 1 AND juice_id = 6);
