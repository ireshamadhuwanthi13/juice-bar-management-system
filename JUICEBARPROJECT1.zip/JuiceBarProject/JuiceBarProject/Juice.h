#pragma once
#include "AppIncludes.h"

namespace JuiceBarProject {

    /// <summary>
    /// Abstract Base Class representing a generic Juice Bar product.
    /// Demonstrates ABSTRACTION and ENCAPSULATION.
    /// </summary>
    public ref class Juice abstract {
    protected:
        int id;
        String^ name;
        double basePrice;
        String^ category;
        String^ description;

    public:
        // Parameterized Constructor
        Juice(int id, String^ name, double basePrice, String^ category, String^ description) {
            this->id = id;
            setName(name);
            setBasePrice(basePrice);
            this->category = category;
            this->description = description;
        }

        // ------------------------------------------------------
        // ENCAPSULATION: Getters and Setters with Validation Rules
        // ------------------------------------------------------
        int getId() {
            return id;
        }

        void setId(int value) {
            if (value >= 0) {
                id = value;
            }
        }

        String^ getName() {
            return name;
        }

        void setName(String^ value) {
            if (!String::IsNullOrWhiteSpace(value)) {
                name = value->Trim();
            } else {
                name = "Unnamed Juice";
            }
        }

        double getBasePrice() {
            return basePrice;
        }

        void setBasePrice(double value) {
            if (value >= 0.0) {
                basePrice = value;
            } else {
                basePrice = 0.0;
            }
        }

        String^ getCategory() {
            return category;
        }

        void setCategory(String^ value) {
            category = value;
        }

        String^ getDescription() {
            return description;
        }

        void setDescription(String^ value) {
            description = value;
        }

        // ------------------------------------------------------
        // ABSTRACTION: Pure Virtual Methods (Interface Contract)
        // Must be implemented polymorphically by derived classes
        // ------------------------------------------------------
        virtual double calculatePrice(int quantity, String^ size, bool extraTopping) abstract;
        virtual String^ getPreparationDetails() abstract;
        virtual String^ getCategoryName() abstract;

        // Virtual method with default implementation
        virtual String^ getDisplaySummary() {
            return String::Format("{0} [{1}] - LKR {2:F2}", name, getCategoryName(), basePrice);
        }
    };
}
