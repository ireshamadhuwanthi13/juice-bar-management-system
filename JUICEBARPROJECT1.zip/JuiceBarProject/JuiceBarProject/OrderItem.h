#pragma once

#include "Juice.h"

// ==========================================================
// Rajarata University of Sri Lanka - Faculty of Applied Sciences
// Department of Computing - COM 1305 OOP Mini Project
// 
// OOP CONCEPTS DEMONSTRATED:
// 1. CLASS & OBJECT: OrderItem encapsulates a single line item
// 2. ENCAPSULATION: Validated setters, computed line total
// 3. POLYMORPHISM: Invokes selectedJuice->calculatePrice(...) polymorphically
// ==========================================================

namespace JuiceBarProject {

    /// <summary>
    /// Represents an individual configured item within a customer order.
    /// Demonstrates ENCAPSULATION and POLYMORPHIC INVOCATION.
    /// </summary>
    public ref class OrderItem {
    private:
        Juice^ selectedJuice;
        String^ size;         // "Regular", "Medium", "Large"
        String^ sugarLevel;   // "0% Sugar-Free", "25% Low Sugar", "50% Half Sugar", "100% Normal"
        String^ iceLevel;     // "No Ice", "Less Ice", "Normal Ice", "Extra Ice"
        bool extraTopping;
        int quantity;
        double unitPrice;
        double lineTotal;

    public:
        OrderItem(Juice^ juice, int qty, String^ sz, String^ sugar, String^ ice, bool topping) {
            this->selectedJuice = juice;
            this->size = sz;
            this->sugarLevel = sugar;
            this->iceLevel = ice;
            this->extraTopping = topping;
            setQuantity(qty);
            recalculate();
        }

        // Encapsulation: Accessors & Mutators
        Juice^ getJuice() {
            return selectedJuice;
        }

        void setJuice(Juice^ juice) {
            selectedJuice = juice;
            recalculate();
        }

        String^ getSize() {
            return size;
        }

        void setSize(String^ val) {
            size = val;
            recalculate();
        }

        String^ getSugarLevel() {
            return sugarLevel;
        }

        void setSugarLevel(String^ val) {
            sugarLevel = val;
        }

        String^ getIceLevel() {
            return iceLevel;
        }

        void setIceLevel(String^ val) {
            iceLevel = val;
        }

        bool getExtraTopping() {
            return extraTopping;
        }

        void setExtraTopping(bool val) {
            extraTopping = val;
            recalculate();
        }

        int getQuantity() {
            return quantity;
        }

        void setQuantity(int val) {
            if (val > 0) {
                quantity = val;
            } else {
                quantity = 1;
            }
            recalculate();
        }

        double getUnitPrice() {
            return unitPrice;
        }

        double getLineTotal() {
            return lineTotal;
        }

        // ------------------------------------------------------
        // RUNTIME POLYMORPHIC CALL:
        // Delegates total calculation to the specific derived Juice subclass
        // ------------------------------------------------------
        void recalculate() {
            if (selectedJuice != nullptr) {
                lineTotal = selectedJuice->calculatePrice(quantity, size, extraTopping);
                unitPrice = (quantity > 0) ? (lineTotal / quantity) : selectedJuice->getBasePrice();
            } else {
                lineTotal = 0.0;
                unitPrice = 0.0;
            }
        }

        String^ getItemSummary() {
            if (selectedJuice != nullptr) {
                return String::Format("{0} [{1}] x{2} @ LKR {3:F2} = LKR {4:F2} ({5}, {6}, {7})",
                    selectedJuice->getName(), size, quantity, unitPrice, lineTotal,
                    sugarLevel, iceLevel, (extraTopping ? "Extra Topping" : "Standard"));
            }
            return "Empty Item";
        }
    };
}
