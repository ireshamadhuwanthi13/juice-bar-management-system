#pragma once
#include "AppIncludes.h"
#include "DatabaseManager.h"
#include "DbSettingsForm.h"

namespace JuiceBarProject {

    public ref class OrderHistoryForm : public System::Windows::Forms::Form {
    public:
        OrderHistoryForm(void) {
            InitializeComponent();
            selectedOrderId = -1;
            LoadOrdersData();
            UpdateSalesStats();
        }

    protected:
        ~OrderHistoryForm() {
            if (components) {
                delete components;
            }
        }

    private:
        System::ComponentModel::Container ^components;

        int selectedOrderId;

        // UI Header
        Panel^ headerPanel;
        Label^ lblTitle;
        Label^ lblSubtitle;
        Button^ btnBack;

        // KPI Summary Cards
        Panel^ cardRevenue;
        Label^ lblRevTitle;
        Label^ lblRevValue;

        Panel^ cardOrders;
        Label^ lblOrdersTitle;
        Label^ lblOrdersValue;

        Panel^ cardAvg;
        Label^ lblAvgTitle;
        Label^ lblAvgValue;

        // Filters & Search
        Panel^ actionPanel;
        Label^ lblFilter;
        ComboBox^ cmbStatusFilter;
        Label^ lblSearch;
        TextBox^ txtSearch;
        Button^ btnRefresh;

        // Master Grid (Orders)
        Label^ lblOrdersGrid;
        DataGridView^ gridOrders;

        // Details Grid (Order Items)
        Label^ lblDetailsGrid;
        DataGridView^ gridDetails;

        // Bottom Actions
        Panel^ bottomPanel;
        Label^ lblChangeStatus;
        ComboBox^ cmbNewStatus;
        Button^ btnUpdateStatus;
        Button^ btnDeleteOrder;
        Button^ btnViewReceipt;

        void InitializeComponent(void) {
            this->components = gcnew System::ComponentModel::Container();
            this->Size = System::Drawing::Size(1020, 720);
            this->Text = "Juice Bar - Order History";
            this->StartPosition = FormStartPosition::CenterScreen;
            this->BackColor = Color::FromArgb(245, 247, 250);
            this->Font = gcnew System::Drawing::Font("Segoe UI", 9.5F);

            // Header Panel
            headerPanel = gcnew Panel();
            headerPanel->Dock = DockStyle::Top;
            headerPanel->Height = 75;
            headerPanel->BackColor = Color::FromArgb(230, 81, 0); // Warm Citrus Amber

            lblTitle = gcnew Label();
            lblTitle->Text = "Customer Orders & Sales Analytics";
            lblTitle->ForeColor = Color::White;
            lblTitle->Font = gcnew System::Drawing::Font("Segoe UI", 15.0F, FontStyle::Bold);
            lblTitle->Location = Point(20, 12);
            lblTitle->AutoSize = true;

            lblSubtitle = gcnew Label();
            lblSubtitle->Text = "View transaction history and manage order statuses";
            lblSubtitle->ForeColor = Color::FromArgb(255, 224, 178);
            lblSubtitle->Font = gcnew System::Drawing::Font("Segoe UI", 9.0F);
            lblSubtitle->Location = Point(22, 44);
            lblSubtitle->AutoSize = true;

            btnBack = gcnew Button();
            btnBack->Text = "< Back to POS";
            btnBack->Location = Point(880, 20);
            btnBack->Size = System::Drawing::Size(110, 36);
            btnBack->BackColor = Color::White;
            btnBack->ForeColor = Color::FromArgb(230, 81, 0);
            btnBack->Font = gcnew System::Drawing::Font("Segoe UI", 9.5F, FontStyle::Bold);
            btnBack->FlatStyle = FlatStyle::Flat;
            btnBack->Click += gcnew EventHandler(this, &OrderHistoryForm::btnBack_Click);

            headerPanel->Controls->Add(lblTitle);
            headerPanel->Controls->Add(lblSubtitle);
            headerPanel->Controls->Add(btnBack);
            this->Controls->Add(headerPanel);

            // 3 KPI Analytics Cards
            int cardW = 310;
            int cardH = 70;
            int cardY = 88;

            // Card 1: Revenue
            cardRevenue = gcnew Panel();
            cardRevenue->Location = Point(20, cardY);
            cardRevenue->Size = System::Drawing::Size(cardW, cardH);
            cardRevenue->BackColor = Color::FromArgb(46, 125, 50); // Green
            lblRevTitle = gcnew Label();
            lblRevTitle->Text = "TOTAL REVENUE";
            lblRevTitle->ForeColor = Color::FromArgb(200, 230, 201);
            lblRevTitle->Font = gcnew System::Drawing::Font("Segoe UI", 8.5F, FontStyle::Bold);
            lblRevTitle->Location = Point(15, 10);
            lblRevTitle->AutoSize = true;
            lblRevValue = gcnew Label();
            lblRevValue->Text = "LKR 0.00";
            lblRevValue->ForeColor = Color::White;
            lblRevValue->Font = gcnew System::Drawing::Font("Segoe UI", 16.0F, FontStyle::Bold);
            lblRevValue->Location = Point(12, 28);
            lblRevValue->AutoSize = true;
            cardRevenue->Controls->Add(lblRevTitle);
            cardRevenue->Controls->Add(lblRevValue);
            this->Controls->Add(cardRevenue);

            // Card 2: Orders Count
            cardOrders = gcnew Panel();
            cardOrders->Location = Point(345, cardY);
            cardOrders->Size = System::Drawing::Size(cardW, cardH);
            cardOrders->BackColor = Color::FromArgb(21, 101, 192); // Blue
            lblOrdersTitle = gcnew Label();
            lblOrdersTitle->Text = "COMPLETED ORDERS";
            lblOrdersTitle->ForeColor = Color::FromArgb(187, 222, 251);
            lblOrdersTitle->Font = gcnew System::Drawing::Font("Segoe UI", 8.5F, FontStyle::Bold);
            lblOrdersTitle->Location = Point(15, 10);
            lblOrdersTitle->AutoSize = true;
            lblOrdersValue = gcnew Label();
            lblOrdersValue->Text = "0 Orders";
            lblOrdersValue->ForeColor = Color::White;
            lblOrdersValue->Font = gcnew System::Drawing::Font("Segoe UI", 16.0F, FontStyle::Bold);
            lblOrdersValue->Location = Point(12, 28);
            lblOrdersValue->AutoSize = true;
            cardOrders->Controls->Add(lblOrdersTitle);
            cardOrders->Controls->Add(lblOrdersValue);
            this->Controls->Add(cardOrders);

            // Card 3: Items Sold
            cardAvg = gcnew Panel();
            cardAvg->Location = Point(670, cardY);
            cardAvg->Size = System::Drawing::Size(cardW, cardH);
            cardAvg->BackColor = Color::FromArgb(106, 27, 154); // Purple
            lblAvgTitle = gcnew Label();
            lblAvgTitle->Text = "TOTAL JUICE CUPS SOLD";
            lblAvgTitle->ForeColor = Color::FromArgb(225, 190, 231);
            lblAvgTitle->Font = gcnew System::Drawing::Font("Segoe UI", 8.5F, FontStyle::Bold);
            lblAvgTitle->Location = Point(15, 10);
            lblAvgTitle->AutoSize = true;
            lblAvgValue = gcnew Label();
            lblAvgValue->Text = "0 Cups";
            lblAvgValue->ForeColor = Color::White;
            lblAvgValue->Font = gcnew System::Drawing::Font("Segoe UI", 16.0F, FontStyle::Bold);
            lblAvgValue->Location = Point(12, 28);
            lblAvgValue->AutoSize = true;
            cardAvg->Controls->Add(lblAvgTitle);
            cardAvg->Controls->Add(lblAvgValue);
            this->Controls->Add(cardAvg);

            // Action / Filter Panel
            actionPanel = gcnew Panel();
            actionPanel->Location = Point(20, 170);
            actionPanel->Size = System::Drawing::Size(960, 42);
            actionPanel->BackColor = Color::White;
            actionPanel->BorderStyle = BorderStyle::FixedSingle;

            lblSearch = gcnew Label();
            lblSearch->Text = "Search Customer:";
            lblSearch->Location = Point(12, 10);
            lblSearch->AutoSize = true;
            actionPanel->Controls->Add(lblSearch);

            txtSearch = gcnew TextBox();
            txtSearch->Location = Point(135, 7);
            txtSearch->Size = System::Drawing::Size(220, 25);
            txtSearch->TextChanged += gcnew EventHandler(this, &OrderHistoryForm::txtSearch_TextChanged);
            actionPanel->Controls->Add(txtSearch);

            lblFilter = gcnew Label();
            lblFilter->Text = "Status:";
            lblFilter->Location = Point(380, 10);
            lblFilter->AutoSize = true;
            actionPanel->Controls->Add(lblFilter);

            cmbStatusFilter = gcnew ComboBox();
            cmbStatusFilter->Location = Point(435, 7);
            cmbStatusFilter->Size = System::Drawing::Size(150, 25);
            cmbStatusFilter->DropDownStyle = ComboBoxStyle::DropDownList;
            cmbStatusFilter->Items->AddRange(gcnew cli::array<Object^> { "All Statuses", "Completed", "Pending", "Cancelled" });
            cmbStatusFilter->SelectedIndex = 0;
            cmbStatusFilter->SelectedIndexChanged += gcnew EventHandler(this, &OrderHistoryForm::cmbStatusFilter_SelectedIndexChanged);
            actionPanel->Controls->Add(cmbStatusFilter);

            btnRefresh = gcnew Button();
            btnRefresh->Text = "Refresh";
            btnRefresh->Location = Point(845, 6);
            btnRefresh->Size = System::Drawing::Size(100, 28);
            btnRefresh->BackColor = Color::FromArgb(33, 150, 243);
            btnRefresh->ForeColor = Color::White;
            btnRefresh->FlatStyle = FlatStyle::Flat;
            btnRefresh->Click += gcnew EventHandler(this, &OrderHistoryForm::btnRefresh_Click);
            actionPanel->Controls->Add(btnRefresh);

            this->Controls->Add(actionPanel);

            // Grids Layout
            lblOrdersGrid = gcnew Label();
            lblOrdersGrid->Text = "Master Orders List (Click an order to inspect ordered items):";
            lblOrdersGrid->Location = Point(20, 222);
            lblOrdersGrid->Font = gcnew System::Drawing::Font("Segoe UI", 9.5F, FontStyle::Bold);
            lblOrdersGrid->AutoSize = true;
            this->Controls->Add(lblOrdersGrid);

            gridOrders = gcnew DataGridView();
            gridOrders->Location = Point(20, 245);
            gridOrders->Size = System::Drawing::Size(520, 340);
            gridOrders->BackgroundColor = Color::White;
            gridOrders->ReadOnly = true;
            gridOrders->AllowUserToAddRows = false;
            gridOrders->SelectionMode = DataGridViewSelectionMode::FullRowSelect;
            gridOrders->MultiSelect = false;
            gridOrders->AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode::Fill;
            gridOrders->RowHeadersVisible = false;
            gridOrders->SelectionChanged += gcnew EventHandler(this, &OrderHistoryForm::gridOrders_SelectionChanged);
            this->Controls->Add(gridOrders);

            lblDetailsGrid = gcnew Label();
            lblDetailsGrid->Text = "Selected Order Items Breakdown:";
            lblDetailsGrid->Location = Point(555, 222);
            lblDetailsGrid->Font = gcnew System::Drawing::Font("Segoe UI", 9.5F, FontStyle::Bold);
            lblDetailsGrid->AutoSize = true;
            this->Controls->Add(lblDetailsGrid);

            gridDetails = gcnew DataGridView();
            gridDetails->Location = Point(555, 245);
            gridDetails->Size = System::Drawing::Size(425, 340);
            gridDetails->BackgroundColor = Color::White;
            gridDetails->ReadOnly = true;
            gridDetails->AllowUserToAddRows = false;
            gridDetails->SelectionMode = DataGridViewSelectionMode::FullRowSelect;
            gridDetails->MultiSelect = false;
            gridDetails->AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode::Fill;
            gridDetails->RowHeadersVisible = false;
            this->Controls->Add(gridDetails);

            // Bottom Action Panel
            bottomPanel = gcnew Panel();
            bottomPanel->Location = Point(20, 600);
            bottomPanel->Size = System::Drawing::Size(960, 60);
            bottomPanel->BackColor = Color::White;
            bottomPanel->BorderStyle = BorderStyle::FixedSingle;

            lblChangeStatus = gcnew Label();
            lblChangeStatus->Text = "Change Order Status:";
            lblChangeStatus->Location = Point(15, 18);
            lblChangeStatus->AutoSize = true;
            bottomPanel->Controls->Add(lblChangeStatus);

            cmbNewStatus = gcnew ComboBox();
            cmbNewStatus->Location = Point(155, 15);
            cmbNewStatus->Size = System::Drawing::Size(140, 25);
            cmbNewStatus->DropDownStyle = ComboBoxStyle::DropDownList;
            cmbNewStatus->Items->AddRange(gcnew cli::array<Object^> { "Completed", "Pending", "Cancelled" });
            cmbNewStatus->SelectedIndex = 0;
            bottomPanel->Controls->Add(cmbNewStatus);

            btnUpdateStatus = gcnew Button();
            btnUpdateStatus->Text = "Update Status";
            btnUpdateStatus->Location = Point(305, 13);
            btnUpdateStatus->Size = System::Drawing::Size(125, 32);
            btnUpdateStatus->BackColor = Color::FromArgb(239, 108, 0);
            btnUpdateStatus->ForeColor = Color::White;
            btnUpdateStatus->FlatStyle = FlatStyle::Flat;
            btnUpdateStatus->Click += gcnew EventHandler(this, &OrderHistoryForm::btnUpdateStatus_Click);
            bottomPanel->Controls->Add(btnUpdateStatus);

            btnDeleteOrder = gcnew Button();
            btnDeleteOrder->Text = "Delete Order";
            btnDeleteOrder->Location = Point(440, 13);
            btnDeleteOrder->Size = System::Drawing::Size(125, 32);
            btnDeleteOrder->BackColor = Color::FromArgb(198, 40, 40);
            btnDeleteOrder->ForeColor = Color::White;
            btnDeleteOrder->FlatStyle = FlatStyle::Flat;
            btnDeleteOrder->Click += gcnew EventHandler(this, &OrderHistoryForm::btnDeleteOrder_Click);
            bottomPanel->Controls->Add(btnDeleteOrder);

            btnViewReceipt = gcnew Button();
            btnViewReceipt->Text = "View Full Receipt";
            btnViewReceipt->Location = Point(800, 13);
            btnViewReceipt->Size = System::Drawing::Size(145, 32);
            btnViewReceipt->BackColor = Color::FromArgb(46, 125, 50);
            btnViewReceipt->ForeColor = Color::White;
            btnViewReceipt->FlatStyle = FlatStyle::Flat;
            btnViewReceipt->Click += gcnew EventHandler(this, &OrderHistoryForm::btnViewReceipt_Click);
            bottomPanel->Controls->Add(btnViewReceipt);

            this->Controls->Add(bottomPanel);
        }

        void LoadOrdersData() {
            try {
                DataTable^ dt = DatabaseManager::GetInstance()->GetAllOrders();
                gridOrders->DataSource = dt;
                if (gridOrders->Columns->Contains("id")) {
                    gridOrders->Columns["id"]->HeaderText = "ID";
                }
                if (gridOrders->Columns->Contains("customer_name")) {
                    gridOrders->Columns["customer_name"]->HeaderText = "Customer";
                }
                if (gridOrders->Columns->Contains("order_date")) {
                    gridOrders->Columns["order_date"]->HeaderText = "Date & Time";
                    gridOrders->Columns["order_date"]->DefaultCellStyle->Format = "MM/dd HH:mm";
                }
                if (gridOrders->Columns->Contains("total_amount")) {
                    gridOrders->Columns["total_amount"]->HeaderText = "Total (LKR)";
                    gridOrders->Columns["total_amount"]->DefaultCellStyle->Format = "F2";
                }
                if (gridOrders->Columns->Contains("status")) {
                    gridOrders->Columns["status"]->HeaderText = "Status";
                }
            } catch (Exception^) {
                // Safeguard against layout exceptions
            }
        }

        void UpdateSalesStats() {
            double totalRev = 0.0;
            int totalOrders = 0;
            int totalJuices = 0;
            DatabaseManager::GetInstance()->GetSalesStatistics(totalRev, totalOrders, totalJuices);

            lblRevValue->Text = String::Format("LKR {0:N2}", totalRev);
            lblOrdersValue->Text = String::Format("{0} Orders", totalOrders);
            lblAvgValue->Text = String::Format("{0} Cups", totalJuices);
        }

        void ApplyFilters() {
            DataTable^ dt = dynamic_cast<DataTable^>(gridOrders->DataSource);
            if (dt != nullptr) {
                String^ filter = "";
                String^ term = txtSearch->Text->Trim()->Replace("'", "''");
                if (!String::IsNullOrEmpty(term)) {
                    filter = String::Format("customer_name LIKE '%{0}%'", term);
                }

                String^ selectedStatus = cmbStatusFilter->SelectedItem != nullptr ? cmbStatusFilter->SelectedItem->ToString() : "All Statuses";
                if (selectedStatus != "All Statuses") {
                    if (!String::IsNullOrEmpty(filter)) filter += " AND ";
                    filter += String::Format("status = '{0}'", selectedStatus);
                }
                dt->DefaultView->RowFilter = filter;
            }
        }

        void txtSearch_TextChanged(Object^ sender, EventArgs^ e) {
            ApplyFilters();
        }

        void cmbStatusFilter_SelectedIndexChanged(Object^ sender, EventArgs^ e) {
            ApplyFilters();
        }

        void gridOrders_SelectionChanged(Object^ sender, EventArgs^ e) {
            if (gridOrders->SelectedRows->Count > 0) {
                DataGridViewRow^ row = gridOrders->SelectedRows[0];
                if (row->Cells["id"]->Value != nullptr && row->Cells["id"]->Value != DBNull::Value) {
                    selectedOrderId = Convert::ToInt32(row->Cells["id"]->Value);
                    String^ currentStatus = row->Cells["status"]->Value->ToString();
                    if (cmbNewStatus->Items->Contains(currentStatus)) {
                        cmbNewStatus->SelectedItem = currentStatus;
                    }

                    // Load detailed order items
                    DataTable^ dtItems = DatabaseManager::GetInstance()->GetOrderItems(selectedOrderId);
                    gridDetails->DataSource = dtItems;
                    if (gridDetails->Columns->Contains("id")) gridDetails->Columns["id"]->Visible = false;
                    if (gridDetails->Columns->Contains("order_id")) gridDetails->Columns["order_id"]->Visible = false;
                    if (gridDetails->Columns->Contains("item_name")) gridDetails->Columns["item_name"]->HeaderText = "Item";
                    if (gridDetails->Columns->Contains("category")) gridDetails->Columns["category"]->HeaderText = "Type";
                    if (gridDetails->Columns->Contains("unit_price")) {
                        gridDetails->Columns["unit_price"]->HeaderText = "Price";
                        gridDetails->Columns["unit_price"]->DefaultCellStyle->Format = "F2";
                    }
                    if (gridDetails->Columns->Contains("quantity")) gridDetails->Columns["quantity"]->HeaderText = "Qty";
                    if (gridDetails->Columns->Contains("subtotal")) {
                        gridDetails->Columns["subtotal"]->HeaderText = "Subtotal";
                        gridDetails->Columns["subtotal"]->DefaultCellStyle->Format = "F2";
                    }
                }
            } else {
                selectedOrderId = -1;
                gridDetails->DataSource = nullptr;
            }
        }

        void btnUpdateStatus_Click(Object^ sender, EventArgs^ e) {
            if (selectedOrderId <= 0) {
                MessageBox::Show("Please select an order to update its status.", "Selection Required",
                    MessageBoxButtons::OK, MessageBoxIcon::Warning);
                return;
            }

            String^ newSt = cmbNewStatus->SelectedItem->ToString();
            bool ok = DatabaseManager::GetInstance()->UpdateOrderStatus(selectedOrderId, newSt);
            if (ok) {
                MessageBox::Show(String::Format("Order #{0} status updated to '{1}'.", selectedOrderId, newSt),
                    "Status Updated", MessageBoxButtons::OK, MessageBoxIcon::Information);
                LoadOrdersData();
                UpdateSalesStats();
            } else {
                MessageBox::Show("Failed to update status.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
            }
        }

        void btnDeleteOrder_Click(Object^ sender, EventArgs^ e) {
            if (selectedOrderId <= 0) {
                MessageBox::Show("Please select an order to delete.", "Selection Required",
                    MessageBoxButtons::OK, MessageBoxIcon::Warning);
                return;
            }

            System::Windows::Forms::DialogResult dr = MessageBox::Show(
                String::Format("Are you sure you want to permanently delete Order #{0} and all its item records?", selectedOrderId),
                "Confirm Deletion", MessageBoxButtons::YesNo, MessageBoxIcon::Question);

            if (dr == System::Windows::Forms::DialogResult::Yes) {
                bool ok = DatabaseManager::GetInstance()->DeleteOrder(selectedOrderId);
                if (ok) {
                    MessageBox::Show("Order record deleted successfully.", "Order Deleted",
                        MessageBoxButtons::OK, MessageBoxIcon::Information);
                    LoadOrdersData();
                    UpdateSalesStats();
                    gridDetails->DataSource = nullptr;
                    selectedOrderId = -1;
                } else {
                    MessageBox::Show("Failed to delete order record.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
                }
            }
        }

        void btnViewReceipt_Click(Object^ sender, EventArgs^ e) {
            if (selectedOrderId <= 0 || gridOrders->SelectedRows->Count == 0) {
                MessageBox::Show("Please select an order first to view its receipt.", "Selection Required",
                    MessageBoxButtons::OK, MessageBoxIcon::Warning);
                return;
            }

            DataGridViewRow^ row = gridOrders->SelectedRows[0];
            String^ cust = row->Cells["customer_name"]->Value->ToString();
            DateTime dt = Convert::ToDateTime(row->Cells["order_date"]->Value);
            double total = Convert::ToDouble(row->Cells["total_amount"]->Value);
            double paid = Convert::ToDouble(row->Cells["paid_amount"]->Value);
            double change = Convert::ToDouble(row->Cells["change_amount"]->Value);
            String^ st = row->Cells["status"]->Value->ToString();

            System::Text::StringBuilder^ sb = gcnew System::Text::StringBuilder();
            sb->AppendLine("==================================================");
            sb->AppendLine("                  Juice Bar                       ");
            sb->AppendLine("==================================================");
            sb->AppendLine(String::Format(" Order ID   : #{0}", selectedOrderId));
            sb->AppendLine(String::Format(" Customer   : {0}", cust));
            sb->AppendLine(String::Format(" Timestamp  : {0:yyyy-MM-dd HH:mm:ss}", dt));
            sb->AppendLine(String::Format(" Status     : {0}", st));
            sb->AppendLine("--------------------------------------------------");

            DataTable^ dtItems = DatabaseManager::GetInstance()->GetOrderItems(selectedOrderId);
            if (dtItems != nullptr) {
                for each (DataRow^ r in dtItems->Rows) {
                    sb->AppendLine(String::Format(" {0} ({1}) x{2} @ LKR {3:F2} = LKR {4:F2}",
                        r["item_name"], r["category"], r["quantity"],
                        Convert::ToDouble(r["unit_price"]), Convert::ToDouble(r["subtotal"])));
                }
            }
            sb->AppendLine("--------------------------------------------------");
            sb->AppendLine(String::Format(" TOTAL      : LKR {0:F2}", total));
            sb->AppendLine(String::Format(" Paid       : LKR {0:F2}", paid));
            sb->AppendLine(String::Format(" Change     : LKR {0:F2}", change));
            sb->AppendLine("==================================================");

            MessageBox::Show(sb->ToString(), String::Format("Receipt - Order #{0}", selectedOrderId),
                MessageBoxButtons::OK, MessageBoxIcon::Information);
        }

        void btnRefresh_Click(Object^ sender, EventArgs^ e) {
            LoadOrdersData();
            UpdateSalesStats();
        }

        void btnBack_Click(Object^ sender, EventArgs^ e) {
            this->Close();
        }
    };
}
