#pragma once
#include "AppIncludes.h"
#include "DatabaseManager.h"
#include "DbSettingsForm.h"

namespace JuiceBarProject {

    public ref class ManageMenuForm : public System::Windows::Forms::Form {
    public:
        ManageMenuForm(void) {
            InitializeComponent();
            selectedJuiceId = -1;
            LoadJuicesData();
        }

    protected:
        ~ManageMenuForm() {
            if (components) {
                delete components;
            }
        }

    private:
        System::ComponentModel::Container ^components;

        int selectedJuiceId;

        // UI Panels
        Panel^ headerPanel;
        Label^ lblTitle;
        Label^ lblSubtitle;

        Panel^ inputPanel;
        Label^ lblInputHeader;
        Label^ lblIdDisplay;

        Label^ lblName;
        TextBox^ txtName;

        Label^ lblCategory;
        ComboBox^ cmbCategory;

        Label^ lblPrice;
        NumericUpDown^ numPrice;

        Label^ lblFruit;
        TextBox^ txtFruit;

        Label^ lblMilkYogurt;
        TextBox^ txtMilkYogurt;

        Label^ lblDesc;
        TextBox^ txtDesc;

        CheckBox^ chkSpecialty;

        Button^ btnAdd;
        Button^ btnUpdate;
        Button^ btnDelete;
        Button^ btnClear;
        Button^ btnBack;

        Panel^ listPanel;
        Label^ lblSearch;
        TextBox^ txtSearch;
        Button^ btnRefresh;
        DataGridView^ gridJuices;

        void InitializeComponent(void) {
            this->components = gcnew System::ComponentModel::Container();
            this->Size = System::Drawing::Size(980, 680);
            this->Text = "Juice Bar - Menu Management";
            this->StartPosition = FormStartPosition::CenterScreen;
            this->BackColor = Color::FromArgb(245, 247, 250);
            this->Font = gcnew System::Drawing::Font("Segoe UI", 9.5F);

            // Header Panel
            headerPanel = gcnew Panel();
            headerPanel->Dock = DockStyle::Top;
            headerPanel->Height = 75;
            headerPanel->BackColor = Color::FromArgb(0, 121, 107); // Fresh Teal

            lblTitle = gcnew Label();
            lblTitle->Text = "Menu & Product Management";
            lblTitle->ForeColor = Color::White;
            lblTitle->Font = gcnew System::Drawing::Font("Segoe UI", 15.0F, FontStyle::Bold);
            lblTitle->Location = Point(20, 12);
            lblTitle->AutoSize = true;

            lblSubtitle = gcnew Label();
            lblSubtitle->Text = "Add, edit, and update juice bar items";
            lblSubtitle->ForeColor = Color::FromArgb(178, 223, 219);
            lblSubtitle->Font = gcnew System::Drawing::Font("Segoe UI", 9.0F);
            lblSubtitle->Location = Point(22, 44);
            lblSubtitle->AutoSize = true;

            btnBack = gcnew Button();
            btnBack->Text = "< Back to POS";
            btnBack->Location = Point(840, 20);
            btnBack->Size = System::Drawing::Size(110, 36);
            btnBack->BackColor = Color::FromArgb(255, 255, 255);
            btnBack->ForeColor = Color::FromArgb(0, 121, 107);
            btnBack->Font = gcnew System::Drawing::Font("Segoe UI", 9.5F, FontStyle::Bold);
            btnBack->FlatStyle = FlatStyle::Flat;
            btnBack->Click += gcnew EventHandler(this, &ManageMenuForm::btnBack_Click);

            headerPanel->Controls->Add(lblTitle);
            headerPanel->Controls->Add(lblSubtitle);
            headerPanel->Controls->Add(btnBack);
            this->Controls->Add(headerPanel);

            // Left Input Form Panel
            inputPanel = gcnew Panel();
            inputPanel->Location = Point(20, 95);
            inputPanel->Size = System::Drawing::Size(340, 530);
            inputPanel->BackColor = Color::White;
            inputPanel->BorderStyle = BorderStyle::FixedSingle;

            lblInputHeader = gcnew Label();
            lblInputHeader->Text = "Product Editor";
            lblInputHeader->Font = gcnew System::Drawing::Font("Segoe UI", 12.0F, FontStyle::Bold);
            lblInputHeader->ForeColor = Color::FromArgb(0, 121, 107);
            lblInputHeader->Location = Point(15, 12);
            lblInputHeader->AutoSize = true;
            inputPanel->Controls->Add(lblInputHeader);

            lblIdDisplay = gcnew Label();
            lblIdDisplay->Text = "Mode: Adding New Item";
            lblIdDisplay->Font = gcnew System::Drawing::Font("Segoe UI", 8.5F, FontStyle::Italic);
            lblIdDisplay->ForeColor = Color::Gray;
            lblIdDisplay->Location = Point(16, 36);
            lblIdDisplay->AutoSize = true;
            inputPanel->Controls->Add(lblIdDisplay);

            int curY = 65;
            int step = 52;

            // Name
            lblName = gcnew Label();
            lblName->Text = "Product Name:";
            lblName->Location = Point(15, curY);
            lblName->AutoSize = true;
            inputPanel->Controls->Add(lblName);

            txtName = gcnew TextBox();
            txtName->Location = Point(15, curY + 20);
            txtName->Size = System::Drawing::Size(305, 25);
            inputPanel->Controls->Add(txtName);

            // Category
            curY += step;
            lblCategory = gcnew Label();
            lblCategory->Text = "Category:";
            lblCategory->Location = Point(15, curY);
            lblCategory->AutoSize = true;
            inputPanel->Controls->Add(lblCategory);

            cmbCategory = gcnew ComboBox();
            cmbCategory->Location = Point(15, curY + 20);
            cmbCategory->Size = System::Drawing::Size(305, 25);
            cmbCategory->DropDownStyle = ComboBoxStyle::DropDownList;
            cmbCategory->Items->AddRange(gcnew cli::array<Object^> { "Fresh Juice", "Milkshake", "Smoothie" });
            cmbCategory->SelectedIndex = 0;
            inputPanel->Controls->Add(cmbCategory);

            // Price
            curY += step;
            lblPrice = gcnew Label();
            lblPrice->Text = "Base Price (LKR):";
            lblPrice->Location = Point(15, curY);
            lblPrice->AutoSize = true;
            inputPanel->Controls->Add(lblPrice);

            numPrice = gcnew NumericUpDown();
            numPrice->Location = Point(15, curY + 20);
            numPrice->Size = System::Drawing::Size(305, 25);
            numPrice->Maximum = Decimal(10000);
            numPrice->Minimum = Decimal(10);
            numPrice->DecimalPlaces = 2;
            numPrice->Value = Decimal(350);
            inputPanel->Controls->Add(numPrice);

            // Fruit Type
            curY += step;
            lblFruit = gcnew Label();
            lblFruit->Text = "Primary Fruit / Flavor:";
            lblFruit->Location = Point(15, curY);
            lblFruit->AutoSize = true;
            inputPanel->Controls->Add(lblFruit);

            txtFruit = gcnew TextBox();
            txtFruit->Location = Point(15, curY + 20);
            txtFruit->Size = System::Drawing::Size(305, 25);
            inputPanel->Controls->Add(txtFruit);

            // Milk or Yogurt Type
            curY += step;
            lblMilkYogurt = gcnew Label();
            lblMilkYogurt->Text = "Milk / Yogurt Base (Optional):";
            lblMilkYogurt->Location = Point(15, curY);
            lblMilkYogurt->AutoSize = true;
            inputPanel->Controls->Add(lblMilkYogurt);

            txtMilkYogurt = gcnew TextBox();
            txtMilkYogurt->Location = Point(15, curY + 20);
            txtMilkYogurt->Size = System::Drawing::Size(305, 25);
            inputPanel->Controls->Add(txtMilkYogurt);

            // Description
            curY += step;
            lblDesc = gcnew Label();
            lblDesc->Text = "Description:";
            lblDesc->Location = Point(15, curY);
            lblDesc->AutoSize = true;
            inputPanel->Controls->Add(lblDesc);

            txtDesc = gcnew TextBox();
            txtDesc->Location = Point(15, curY + 20);
            txtDesc->Size = System::Drawing::Size(305, 25);
            inputPanel->Controls->Add(txtDesc);

            // Specialty Checkbox
            curY += step - 5;
            chkSpecialty = gcnew CheckBox();
            chkSpecialty->Text = "Specialty / Chef's Premium Item";
            chkSpecialty->Location = Point(15, curY + 12);
            chkSpecialty->AutoSize = true;
            inputPanel->Controls->Add(chkSpecialty);

            // Buttons
            curY += 45;
            btnAdd = gcnew Button();
            btnAdd->Text = "+ Add Juice";
            btnAdd->Location = Point(15, curY);
            btnAdd->Size = System::Drawing::Size(145, 34);
            btnAdd->BackColor = Color::FromArgb(46, 125, 50);
            btnAdd->ForeColor = Color::White;
            btnAdd->FlatStyle = FlatStyle::Flat;
            btnAdd->Click += gcnew EventHandler(this, &ManageMenuForm::btnAdd_Click);
            inputPanel->Controls->Add(btnAdd);

            btnUpdate = gcnew Button();
            btnUpdate->Text = "Save Update";
            btnUpdate->Location = Point(175, curY);
            btnUpdate->Size = System::Drawing::Size(145, 34);
            btnUpdate->BackColor = Color::FromArgb(239, 108, 0);
            btnUpdate->ForeColor = Color::White;
            btnUpdate->FlatStyle = FlatStyle::Flat;
            btnUpdate->Click += gcnew EventHandler(this, &ManageMenuForm::btnUpdate_Click);
            inputPanel->Controls->Add(btnUpdate);

            curY += 40;
            btnDelete = gcnew Button();
            btnDelete->Text = "Delete Item";
            btnDelete->Location = Point(15, curY);
            btnDelete->Size = System::Drawing::Size(145, 34);
            btnDelete->BackColor = Color::FromArgb(198, 40, 40);
            btnDelete->ForeColor = Color::White;
            btnDelete->FlatStyle = FlatStyle::Flat;
            btnDelete->Click += gcnew EventHandler(this, &ManageMenuForm::btnDelete_Click);
            inputPanel->Controls->Add(btnDelete);

            btnClear = gcnew Button();
            btnClear->Text = "Clear Fields";
            btnClear->Location = Point(175, curY);
            btnClear->Size = System::Drawing::Size(145, 34);
            btnClear->BackColor = Color::FromArgb(120, 144, 156);
            btnClear->ForeColor = Color::White;
            btnClear->FlatStyle = FlatStyle::Flat;
            btnClear->Click += gcnew EventHandler(this, &ManageMenuForm::btnClear_Click);
            inputPanel->Controls->Add(btnClear);

            this->Controls->Add(inputPanel);

            // Right Grid Panel
            listPanel = gcnew Panel();
            listPanel->Location = Point(375, 95);
            listPanel->Size = System::Drawing::Size(575, 530);
            listPanel->BackColor = Color::White;
            listPanel->BorderStyle = BorderStyle::FixedSingle;

            lblSearch = gcnew Label();
            lblSearch->Text = "Search Menu:";
            lblSearch->Location = Point(15, 18);
            lblSearch->AutoSize = true;
            listPanel->Controls->Add(lblSearch);

            txtSearch = gcnew TextBox();
            txtSearch->Location = Point(110, 15);
            txtSearch->Size = System::Drawing::Size(330, 25);
            txtSearch->TextChanged += gcnew EventHandler(this, &ManageMenuForm::txtSearch_TextChanged);
            listPanel->Controls->Add(txtSearch);

            btnRefresh = gcnew Button();
            btnRefresh->Text = "Refresh";
            btnRefresh->Location = Point(450, 14);
            btnRefresh->Size = System::Drawing::Size(105, 28);
            btnRefresh->BackColor = Color::FromArgb(33, 150, 243);
            btnRefresh->ForeColor = Color::White;
            btnRefresh->FlatStyle = FlatStyle::Flat;
            btnRefresh->Click += gcnew EventHandler(this, &ManageMenuForm::btnRefresh_Click);
            listPanel->Controls->Add(btnRefresh);

            gridJuices = gcnew DataGridView();
            gridJuices->Location = Point(15, 55);
            gridJuices->Size = System::Drawing::Size(542, 460);
            gridJuices->BackgroundColor = Color::FromArgb(250, 250, 250);
            gridJuices->ReadOnly = true;
            gridJuices->AllowUserToAddRows = false;
            gridJuices->SelectionMode = DataGridViewSelectionMode::FullRowSelect;
            gridJuices->MultiSelect = false;
            gridJuices->AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode::Fill;
            gridJuices->RowHeadersVisible = false;
            gridJuices->SelectionChanged += gcnew EventHandler(this, &ManageMenuForm::gridJuices_SelectionChanged);
            listPanel->Controls->Add(gridJuices);

            this->Controls->Add(listPanel);
        }

        void LoadJuicesData() {
            try {
                DataTable^ dt = DatabaseManager::GetInstance()->GetAllJuices();
                gridJuices->DataSource = dt;
                if (gridJuices->Columns->Contains("id")) {
                    gridJuices->Columns["id"]->HeaderText = "ID";
                }
                if (gridJuices->Columns->Contains("name")) {
                    gridJuices->Columns["name"]->HeaderText = "Product Name";
                }
                if (gridJuices->Columns->Contains("category")) {
                    gridJuices->Columns["category"]->HeaderText = "Category";
                }
                if (gridJuices->Columns->Contains("price")) {
                    gridJuices->Columns["price"]->HeaderText = "Price (LKR)";
                    gridJuices->Columns["price"]->DefaultCellStyle->Format = "F2";
                }
            } catch (Exception^) {
                // Safeguard against layout exceptions
            }
        }

        void txtSearch_TextChanged(Object^ sender, EventArgs^ e) {
            DataTable^ dt = dynamic_cast<DataTable^>(gridJuices->DataSource);
            if (dt != nullptr) {
                String^ term = txtSearch->Text->Trim()->Replace("'", "''");
                if (String::IsNullOrEmpty(term)) {
                    dt->DefaultView->RowFilter = "";
                } else {
                    dt->DefaultView->RowFilter = String::Format("name LIKE '%{0}%' OR category LIKE '%{0}%' OR fruit_type LIKE '%{0}%'", term);
                }
            }
        }

        void gridJuices_SelectionChanged(Object^ sender, EventArgs^ e) {
            if (gridJuices->SelectedRows->Count > 0) {
                DataGridViewRow^ row = gridJuices->SelectedRows[0];
                if (row->Cells["id"]->Value != nullptr && row->Cells["id"]->Value != DBNull::Value) {
                    selectedJuiceId = Convert::ToInt32(row->Cells["id"]->Value);
                    lblIdDisplay->Text = String::Format("Editing Item ID: {0}", selectedJuiceId);

                    txtName->Text = row->Cells["name"]->Value->ToString();
                    String^ cat = row->Cells["category"]->Value->ToString();
                    if (cmbCategory->Items->Contains(cat)) {
                        cmbCategory->SelectedItem = cat;
                    }
                    numPrice->Value = Convert::ToDecimal(row->Cells["price"]->Value);
                    txtDesc->Text = (row->Cells["description"]->Value != nullptr && row->Cells["description"]->Value != DBNull::Value) ? row->Cells["description"]->Value->ToString() : "";
                    txtFruit->Text = (row->Cells["fruit_type"]->Value != nullptr && row->Cells["fruit_type"]->Value != DBNull::Value) ? row->Cells["fruit_type"]->Value->ToString() : "";
                    txtMilkYogurt->Text = (row->Cells["milk_or_yogurt_type"]->Value != nullptr && row->Cells["milk_or_yogurt_type"]->Value != DBNull::Value) ? row->Cells["milk_or_yogurt_type"]->Value->ToString() : "";
                    chkSpecialty->Checked = (row->Cells["is_specialty"]->Value != nullptr && row->Cells["is_specialty"]->Value != DBNull::Value) ? Convert::ToBoolean(row->Cells["is_specialty"]->Value) : false;
                }
            }
        }

        void btnClear_Click(Object^ sender, EventArgs^ e) {
            selectedJuiceId = -1;
            lblIdDisplay->Text = "Mode: Adding New Item";
            txtName->Clear();
            cmbCategory->SelectedIndex = 0;
            numPrice->Value = Decimal(350);
            txtFruit->Clear();
            txtMilkYogurt->Clear();
            txtDesc->Clear();
            chkSpecialty->Checked = false;
            gridJuices->ClearSelection();
        }

        void btnAdd_Click(Object^ sender, EventArgs^ e) {
            String^ name = txtName->Text->Trim();
            if (String::IsNullOrEmpty(name)) {
                MessageBox::Show("Please enter a valid product name.", "Input Validation",
                    MessageBoxButtons::OK, MessageBoxIcon::Warning);
                return;
            }

            String^ cat = cmbCategory->SelectedItem->ToString();
            double price = Convert::ToDouble(numPrice->Value);
            String^ desc = txtDesc->Text->Trim();
            String^ fruit = txtFruit->Text->Trim();
            String^ milk = txtMilkYogurt->Text->Trim();
            bool spec = chkSpecialty->Checked;

            bool success = DatabaseManager::GetInstance()->AddJuice(name, cat, price, desc, fruit, milk, spec);
            if (success) {
                MessageBox::Show("Juice item added successfully!", "Product Added",
                    MessageBoxButtons::OK, MessageBoxIcon::Information);
                LoadJuicesData();
                btnClear_Click(nullptr, nullptr);
            } else {
                String^ err = DatabaseManager::GetInstance()->GetLastErrorMessage();
                MessageBox::Show("Failed to add juice item to MySQL database" + (String::IsNullOrEmpty(err) ? "." : (":\n\n" + err)),
                    "Database Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
            }
        }

        void btnUpdate_Click(Object^ sender, EventArgs^ e) {
            if (selectedJuiceId <= 0) {
                MessageBox::Show("Please select an item from the table to update.", "Selection Required",
                    MessageBoxButtons::OK, MessageBoxIcon::Warning);
                return;
            }

            String^ name = txtName->Text->Trim();
            if (String::IsNullOrEmpty(name)) {
                MessageBox::Show("Product name cannot be empty.", "Input Validation",
                    MessageBoxButtons::OK, MessageBoxIcon::Warning);
                return;
            }

            String^ cat = cmbCategory->SelectedItem->ToString();
            double price = Convert::ToDouble(numPrice->Value);
            String^ desc = txtDesc->Text->Trim();
            String^ fruit = txtFruit->Text->Trim();
            String^ milk = txtMilkYogurt->Text->Trim();
            bool spec = chkSpecialty->Checked;

            bool success = DatabaseManager::GetInstance()->UpdateJuice(selectedJuiceId, name, cat, price, desc, fruit, milk, spec);
            if (success) {
                MessageBox::Show("Juice item updated successfully!", "Product Updated",
                    MessageBoxButtons::OK, MessageBoxIcon::Information);
                LoadJuicesData();
            } else {
                String^ err = DatabaseManager::GetInstance()->GetLastErrorMessage();
                MessageBox::Show("Failed to update juice item in MySQL database" + (String::IsNullOrEmpty(err) ? "." : (":\n\n" + err)),
                    "Database Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
            }
        }

        void btnDelete_Click(Object^ sender, EventArgs^ e) {
            if (selectedJuiceId <= 0) {
                MessageBox::Show("Please select an item from the table to delete.", "Selection Required",
                    MessageBoxButtons::OK, MessageBoxIcon::Warning);
                return;
            }

            System::Windows::Forms::DialogResult dr = MessageBox::Show(
                String::Format("Are you sure you want to delete '{0}' (ID: {1})?", txtName->Text, selectedJuiceId),
                "Confirm Deletion", MessageBoxButtons::YesNo, MessageBoxIcon::Question);

            if (dr == System::Windows::Forms::DialogResult::Yes) {
                bool success = DatabaseManager::GetInstance()->DeleteJuice(selectedJuiceId);
                if (success) {
                    MessageBox::Show("Juice item deleted successfully.", "Item Deleted",
                        MessageBoxButtons::OK, MessageBoxIcon::Information);
                    LoadJuicesData();
                    btnClear_Click(nullptr, nullptr);
                } else {
                    String^ err = DatabaseManager::GetInstance()->GetLastErrorMessage();
                    MessageBox::Show("Failed to delete juice item from MySQL database" + (String::IsNullOrEmpty(err) ? "." : (":\n\n" + err)),
                        "Database Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
                }
            }
        }

        void btnRefresh_Click(Object^ sender, EventArgs^ e) {
            LoadJuicesData();
        }

        void btnBack_Click(Object^ sender, EventArgs^ e) {
            this->Close();
        }
    };
}
