#pragma once

#include "Juice.h"

// ==========================================================
// Rajarata University of Sri Lanka - Faculty of Applied Sciences
// Department of Computing - COM 1305 OOP Mini Project
// 
// OOP CONCEPTS DEMONSTRATED:
// 1. INHERITANCE: Inherits from abstract base class Juice
// 2. POLYMORPHISM: Overrides calculatePrice, getPreparationDetails, getCategoryName
// 3. ENCAPSULATION: Specialized private attributes for fresh fruit extraction
// ==========================================================

namespace JuiceBarProject {

    /// <summary>
    /// Derived class representing pure freshly squeezed juices.
    /// Demonstrates INHERITANCE and RUNTIME POLYMORPHISM.
    /// </summary>
    public ref class FreshJuice : public Juice {
    private:
        String^ fruitType;
        bool isColdPressed;
        String^ pulpLevel; // e.g. "No Pulp", "Normal Pulp", "Extra Pulp"

    public:
        // Constructor forwarding base attributes to Juice constructor
        FreshJuice(int id, String^ name, double basePrice, String^ description,
                   String^ fruitType, bool coldPressed, String^ pulpLevel)
            : Juice(id, name, basePrice, "Fresh Juice", description) {
            this->fruitType = fruitType;
            this->isColdPressed = coldPressed;
            this->pulpLevel = pulpLevel;
        }

        // Encapsulation: Specialized Getters and Setters
        String^ getFruitType() {
            return fruitType;
        }

        void setFruitType(String^ value) {
            fruitType = value;
        }

        bool getIsColdPressed() {
            return isColdPressed;
        }

        void setIsColdPressed(bool value) {
            isColdPressed = value;
        }

        String^ getPulpLevel() {
            return pulpLevel;
        }

        void setPulpLevel(String^ value) {
            pulpLevel = value;
        }

        // ------------------------------------------------------
        // RUNTIME POLYMORPHISM: Specialized Pricing Calculation
        // ------------------------------------------------------
        virtual double calculatePrice(int quantity, String^ size, bool extraTopping) override {
            double unitPrice = basePrice;

            // Size multiplier
            if (size == "Medium") {
                unitPrice *= 1.25;
            } else if (size == "Large") {
                unitPrice *= 1.50;
            }

            // Fresh juice specialized add-on calculations
            if (isColdPressed) {
                unitPrice += 50.0; // Premium hydraulic cold-press process
            }
            if (extraTopping) {
                unitPrice += 40.0; // Mint leaf and chia seed refresher garnish
            }

            return unitPrice * quantity;
        }

        // ------------------------------------------------------
        // RUNTIME POLYMORPHISM: Preparation Details
        // ------------------------------------------------------
        virtual String^ getPreparationDetails() override {
            return String::Format("Fresh 100% {0} | Extraction: {1} | Pulp: {2}",
                fruitType, (isColdPressed ? "Cold-Pressed" : "Centrifugal Squeezed"), pulpLevel);
        }

        virtual String^ getCategoryName() override {
            return "Fresh Juice";
        }
    };
}
