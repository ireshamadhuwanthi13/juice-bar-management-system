#pragma once
#include "AppIncludes.h"
#include "DatabaseManager.h"

namespace JuiceBarProject {

    public ref class DbSettingsForm : public System::Windows::Forms::Form {
    public:
        DbSettingsForm(void) {
            InitializeComponent();
            LoadCurrentSettings();
        }

    protected:
        ~DbSettingsForm() {
            if (components) {
                delete components;
            }
        }

    private:
        System::ComponentModel::Container ^components;

        // UI Controls
        Panel^ headerPanel;
        Label^ lblTitle;
        Label^ lblSubtitle;

        Label^ lblServer;
        TextBox^ txtServer;

        Label^ lblPort;
        TextBox^ txtPort;

        Label^ lblDatabase;
        TextBox^ txtDatabase;

        Label^ lblUsername;
        TextBox^ txtUsername;

        Label^ lblPassword;
        TextBox^ txtPassword;

        Button^ btnTestConn;
        Button^ btnInitDb;
        Button^ btnSave;
        Button^ btnClose;

        Label^ lblStatus;

        void InitializeComponent(void) {
            this->components = gcnew System::ComponentModel::Container();
            this->Size = System::Drawing::Size(520, 480);
            this->Text = "Juice Bar - Database Settings";
            this->StartPosition = FormStartPosition::CenterParent;
            this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedDialog;
            this->MaximizeBox = false;
            this->MinimizeBox = false;
            this->BackColor = Color::FromArgb(245, 247, 250);
            this->Font = gcnew System::Drawing::Font("Segoe UI", 9.5F);

            // Header
            headerPanel = gcnew Panel();
            headerPanel->Dock = DockStyle::Top;
            headerPanel->Height = 80;
            headerPanel->BackColor = Color::FromArgb(27, 94, 32);

            lblTitle = gcnew Label();
            lblTitle->Text = "MySQL Database Configuration";
            lblTitle->ForeColor = Color::White;
            lblTitle->Font = gcnew System::Drawing::Font("Segoe UI", 14.0F, FontStyle::Bold);
            lblTitle->Location = Point(20, 15);
            lblTitle->AutoSize = true;

            lblSubtitle = gcnew Label();
            lblSubtitle->Text = "Configure real-time connection to MySQL 8.0 server";
            lblSubtitle->ForeColor = Color::FromArgb(200, 230, 201);
            lblSubtitle->Font = gcnew System::Drawing::Font("Segoe UI", 9.0F);
            lblSubtitle->Location = Point(22, 45);
            lblSubtitle->AutoSize = true;

            headerPanel->Controls->Add(lblTitle);
            headerPanel->Controls->Add(lblSubtitle);
            this->Controls->Add(headerPanel);

            int startY = 105;
            int stepY = 48;
            int lblX = 35;
            int txtX = 160;
            int txtWidth = 300;

            // Server
            lblServer = gcnew Label();
            lblServer->Text = "Server Host:";
            lblServer->Location = Point(lblX, startY);
            lblServer->AutoSize = true;
            this->Controls->Add(lblServer);

            txtServer = gcnew TextBox();
            txtServer->Location = Point(txtX, startY - 3);
            txtServer->Size = System::Drawing::Size(txtWidth, 26);
            this->Controls->Add(txtServer);

            // Port
            lblPort = gcnew Label();
            lblPort->Text = "Port:";
            lblPort->Location = Point(lblX, startY + stepY);
            lblPort->AutoSize = true;
            this->Controls->Add(lblPort);

            txtPort = gcnew TextBox();
            txtPort->Location = Point(txtX, startY + stepY - 3);
            txtPort->Size = System::Drawing::Size(txtWidth, 26);
            this->Controls->Add(txtPort);

            // Database
            lblDatabase = gcnew Label();
            lblDatabase->Text = "Database Name:";
            lblDatabase->Location = Point(lblX, startY + stepY * 2);
            lblDatabase->AutoSize = true;
            this->Controls->Add(lblDatabase);

            txtDatabase = gcnew TextBox();
            txtDatabase->Location = Point(txtX, startY + stepY * 2 - 3);
            txtDatabase->Size = System::Drawing::Size(txtWidth, 26);
            this->Controls->Add(txtDatabase);

            // Username
            lblUsername = gcnew Label();
            lblUsername->Text = "Username:";
            lblUsername->Location = Point(lblX, startY + stepY * 3);
            lblUsername->AutoSize = true;
            this->Controls->Add(lblUsername);

            txtUsername = gcnew TextBox();
            txtUsername->Location = Point(txtX, startY + stepY * 3 - 3);
            txtUsername->Size = System::Drawing::Size(txtWidth, 26);
            this->Controls->Add(txtUsername);

            // Password
            lblPassword = gcnew Label();
            lblPassword->Text = "Password:";
            lblPassword->Location = Point(lblX, startY + stepY * 4);
            lblPassword->AutoSize = true;
            this->Controls->Add(lblPassword);

            txtPassword = gcnew TextBox();
            txtPassword->Location = Point(txtX, startY + stepY * 4 - 3);
            txtPassword->Size = System::Drawing::Size(txtWidth, 26);
            txtPassword->PasswordChar = '*';
            this->Controls->Add(txtPassword);

            // Status label
            lblStatus = gcnew Label();
            lblStatus->Location = Point(35, 345);
            lblStatus->Size = System::Drawing::Size(430, 36);
            lblStatus->ForeColor = Color::FromArgb(55, 71, 79);
            lblStatus->Font = gcnew System::Drawing::Font("Segoe UI", 9.0F, FontStyle::Italic);
            this->Controls->Add(lblStatus);

            // Buttons
            btnTestConn = gcnew Button();
            btnTestConn->Text = "Test Connection";
            btnTestConn->Location = Point(35, 390);
            btnTestConn->Size = System::Drawing::Size(125, 34);
            btnTestConn->BackColor = Color::FromArgb(33, 150, 243);
            btnTestConn->ForeColor = Color::White;
            btnTestConn->FlatStyle = FlatStyle::Flat;
            btnTestConn->Click += gcnew EventHandler(this, &DbSettingsForm::btnTestConn_Click);
            this->Controls->Add(btnTestConn);

            btnInitDb = gcnew Button();
            btnInitDb->Text = "Initialize DB & Tables";
            btnInitDb->Location = Point(168, 390);
            btnInitDb->Size = System::Drawing::Size(145, 34);
            btnInitDb->BackColor = Color::FromArgb(46, 125, 50);
            btnInitDb->ForeColor = Color::White;
            btnInitDb->FlatStyle = FlatStyle::Flat;
            btnInitDb->Click += gcnew EventHandler(this, &DbSettingsForm::btnInitDb_Click);
            this->Controls->Add(btnInitDb);

            btnSave = gcnew Button();
            btnSave->Text = "Save";
            btnSave->Location = Point(320, 390);
            btnSave->Size = System::Drawing::Size(75, 34);
            btnSave->BackColor = Color::FromArgb(239, 108, 0);
            btnSave->ForeColor = Color::White;
            btnSave->FlatStyle = FlatStyle::Flat;
            btnSave->Click += gcnew EventHandler(this, &DbSettingsForm::btnSave_Click);
            this->Controls->Add(btnSave);

            btnClose = gcnew Button();
            btnClose->Text = "Close";
            btnClose->Location = Point(402, 390);
            btnClose->Size = System::Drawing::Size(75, 34);
            btnClose->BackColor = Color::FromArgb(120, 144, 156);
            btnClose->ForeColor = Color::White;
            btnClose->FlatStyle = FlatStyle::Flat;
            btnClose->Click += gcnew EventHandler(this, &DbSettingsForm::btnClose_Click);
            this->Controls->Add(btnClose);
        }

        void LoadCurrentSettings() {
            DatabaseManager^ db = DatabaseManager::GetInstance();
            txtServer->Text = db->GetServer();
            txtPort->Text = db->GetPort().ToString();
            txtDatabase->Text = db->GetDatabaseName();
            txtUsername->Text = db->GetUsername();
            txtPassword->Text = db->GetPassword();
        }

        void ApplySettings() {
            int port = 3306;
            Int32::TryParse(txtPort->Text, port);
            DatabaseManager::GetInstance()->SetConnectionParameters(
                txtServer->Text->Trim(),
                port,
                txtDatabase->Text->Trim(),
                txtUsername->Text->Trim(),
                txtPassword->Text
            );
        }

        void btnTestConn_Click(Object^ sender, EventArgs^ e) {
            ApplySettings();
            String^ errorMsg = "";
            bool ok = DatabaseManager::GetInstance()->TestConnection(errorMsg);
            if (ok) {
                lblStatus->ForeColor = Color::FromArgb(46, 125, 50);
                lblStatus->Text = "Success: Successfully connected to MySQL Server!";
                MessageBox::Show("Connected to MySQL server successfully!", "Connection Success",
                    MessageBoxButtons::OK, MessageBoxIcon::Information);
            } else {
                lblStatus->ForeColor = Color::FromArgb(198, 40, 40);
                lblStatus->Text = "Failed: " + errorMsg;
                MessageBox::Show("Failed to connect:\n" + errorMsg, "Connection Failed",
                    MessageBoxButtons::OK, MessageBoxIcon::Error);
            }
        }

        void btnInitDb_Click(Object^ sender, EventArgs^ e) {
            ApplySettings();
            String^ log = "";
            bool ok = DatabaseManager::GetInstance()->InitializeDatabase(log);
            if (ok) {
                lblStatus->ForeColor = Color::FromArgb(46, 125, 50);
                lblStatus->Text = log;
                MessageBox::Show(log + "\nInitial juice menu items and database tables ready!", 
                    "Database Ready", MessageBoxButtons::OK, MessageBoxIcon::Information);
            } else {
                lblStatus->ForeColor = Color::FromArgb(198, 40, 40);
                lblStatus->Text = log;
                MessageBox::Show(log, "Initialization Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
            }
        }

        void btnSave_Click(Object^ sender, EventArgs^ e) {
            ApplySettings();
            lblStatus->ForeColor = Color::FromArgb(46, 125, 50);
            lblStatus->Text = "Settings updated successfully!";
            this->DialogResult = System::Windows::Forms::DialogResult::OK;
            this->Close();
        }

        void btnClose_Click(Object^ sender, EventArgs^ e) {
            this->Close();
        }
    };
}
