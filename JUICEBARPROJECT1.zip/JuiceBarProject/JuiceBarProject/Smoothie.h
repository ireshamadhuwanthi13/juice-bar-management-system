#pragma once

#include "Juice.h"

// ==========================================================
// Rajarata University of Sri Lanka - Faculty of Applied Sciences
// Department of Computing - COM 1305 OOP Mini Project
// 
// OOP CONCEPTS DEMONSTRATED:
// 1. INHERITANCE: Inherits from abstract base class Juice
// 2. POLYMORPHISM: Specialized price calculation with yogurt bases & superfood boosts
// 3. ENCAPSULATION: Yogurt base, protein additions, organic superfood add-ons
// ==========================================================

namespace JuiceBarProject {

    /// <summary>
    /// Derived class representing Smoothies.
    /// Demonstrates INHERITANCE and RUNTIME POLYMORPHISM.
    /// </summary>
    public ref class Smoothie : public Juice {
    private:
        String^ yogurtBase;      // e.g. "Greek Yogurt", "Coconut Yogurt", "Low-Fat"
        bool hasProteinBoost;    // Protein powder scoop
        String^ superfoodAddon;  // e.g. "Chia Seeds", "Flaxseed", "Honey", "None"

    public:
        Smoothie(int id, String^ name, double basePrice, String^ description,
                 String^ yogurtBase, bool hasProteinBoost, String^ superfoodAddon)
            : Juice(id, name, basePrice, "Smoothie", description) {
            this->yogurtBase = yogurtBase;
            this->hasProteinBoost = hasProteinBoost;
            this->superfoodAddon = superfoodAddon;
        }

        // Encapsulation: Specialized Getters and Setters
        String^ getYogurtBase() {
            return yogurtBase;
        }

        void setYogurtBase(String^ value) {
            yogurtBase = value;
        }

        bool getHasProteinBoost() {
            return hasProteinBoost;
        }

        void setHasProteinBoost(bool value) {
            hasProteinBoost = value;
        }

        String^ getSuperfoodAddon() {
            return superfoodAddon;
        }

        void setSuperfoodAddon(String^ value) {
            superfoodAddon = value;
        }

        // ------------------------------------------------------
        // RUNTIME POLYMORPHISM: Specialized Pricing Calculation
        // ------------------------------------------------------
        virtual double calculatePrice(int quantity, String^ size, bool extraTopping) override {
            double unitPrice = basePrice;

            if (size == "Medium") {
                unitPrice *= 1.25;
            } else if (size == "Large") {
                unitPrice *= 1.50;
            }

            // Protein boost addition
            if (hasProteinBoost) {
                unitPrice += 90.0; // Pure organic whey/plant protein scoop
            }

            // Superfood addition
            if (!String::IsNullOrEmpty(superfoodAddon) && superfoodAddon != "None") {
                unitPrice += 50.0;
            }

            // Extra topping: Granola crunch and wild honey drizzle
            if (extraTopping) {
                unitPrice += 40.0;
            }

            return unitPrice * quantity;
        }

        virtual String^ getPreparationDetails() override {
            return String::Format("Base: {0} | Protein Scoop: {1} | Superfood: {2}",
                yogurtBase, (hasProteinBoost ? "Yes" : "No"), superfoodAddon);
        }

        virtual String^ getCategoryName() override {
            return "Smoothie";
        }
    };
}
